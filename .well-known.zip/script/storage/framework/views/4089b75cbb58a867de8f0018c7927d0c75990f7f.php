

<?php $__env->startSection('content'); ?>

   <!-- dahboard area start -->
   <section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="row">
                            <div class="col-9">
                                <h4><?php echo e(__('Other Bank Statments')); ?></h4>
                            </div>
                            <div class="col-3 text-end">
                                <a class="btn btn-primary" href="<?php echo e(route('user.statement.otherbankpdf')); ?>"><?php echo e(__('PDF download')); ?></a>
                            </div>
                        </div>
                        <?php if(Session::has('message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(Session::get('message')); ?>

                        </p>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"><?php echo e(__('Bank Name')); ?></th>
                                        <th scope="col"><?php echo e(__('Transaction Type')); ?></th>
                                        <th scope="col"><?php echo e(__('Amount')); ?></th>
                                        <th scope="col"><?php echo e(__('Currency Rate')); ?></th>
                                        <th scope="col"><?php echo e(__('Status')); ?></th>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($transaction->bank->name); ?></td>
                                            <td><?php echo e($transaction->transaction->type); ?></td>
                                            <td><?php echo e($transaction->amount); ?></td>
                                            <td><?php echo e($transaction->currency_rate); ?></td>
                                            <td><?php echo e($transaction->status == 1 ? 'Success' : ($transaction->status == 2 ? 'Pending' : 'Error')); ?></td>
                                            <td>
                                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('user.others.bank.statement.view', $transaction->id)); ?>">
                                                    <?php echo e(__('View')); ?>

                                                </a>
                                            </td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="float-right">
                                    <?php echo e($transactions->links('vendor.pagination.bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/user/statment/others_bank_statment.blade.php ENDPATH**/ ?>