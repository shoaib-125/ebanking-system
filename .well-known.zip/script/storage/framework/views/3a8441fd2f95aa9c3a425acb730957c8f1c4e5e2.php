

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
              <h4><?php echo e(__('Twilio Edit')); ?></h4>
            </div>
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <strong><?php echo e(__('Whoops!')); ?></strong> <?php echo e(__('There were some problems with your input.')); ?><br><br>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.option.twilio.update', $twilio->id)); ?>" class="basicform_with_reload">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <?php 
                $twilio = json_decode($twilio->value);
              ?>
              <div class="card-body">
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Twilio SID')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($twilio->twilio_sid); ?>" name="twilio_sid" placeholder="Twilio SID" required>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Twilio Auth Token')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($twilio->twilio_auth_token); ?>" name="twilio_auth_token" placeholder="Twilio Auth Token" required>
                    </div>
                  </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-12 col-md-6 col-sm-12">
                      <div class="form-group">
                          <label><?php echo e(__('Twilio Number')); ?></label>
                          <input type="text" class="form-control" value="<?php echo e($twilio->twilio_number); ?>" name="twilio_number" placeholder="Twilio Number" required>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-6 col-sm-12">
                      <div class="form-group">
                          <label><?php echo e(__('Message Template')); ?></label>
                          <textarea name="message" class="form-control"><?php echo e($twilio->message); ?></textarea>
                      </div>
                    </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn">Submit</button>
                  </div>
                </div>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/option/twilio.blade.php ENDPATH**/ ?>