

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4><?php echo e(__('Fixed Deposit Create')); ?></h4>
            </div>
            <form method="POST" action="<?php echo e(route('admin.fixed-deposit.store')); ?>" class="basicform_with_reset">
              <?php echo csrf_field(); ?>
              <div class="card-body">
                <div class="form-group">
                  <label><?php echo e(__('Title')); ?></label>
                  <input type="text" class="form-control" name="title" placeholder="Name" required>
                </div>
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Minimum Amount')); ?></label>
                        <input type="number" step="any" class="form-control" name="min_amount" placeholder="Minimum Amount" required>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo e(__('Maximum Amount')); ?></label>
                      <input type="number" step="any" class="form-control" name="max_amount" placeholder="Maximum Amount" required>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label><?php echo e(__('Percent Return')); ?></label>
                  <input type="number" step="any" class="form-control" name="percent_return" placeholder="Percent Return">
                </div>

                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Duration')); ?></label>
                        <input type="number"  class="form-control" name="duration" placeholder="Days" required>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo e(__('Status')); ?></label>
                      <select name="status" class="form-control">
                      
                        <option value="1"><?php echo e(__('Active')); ?></option>
                        <option value="0"><?php echo e(__('Deactive')); ?></option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn">Submit</button>
                  </div>
                </div>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/admin/fixeddeposit/create.blade.php ENDPATH**/ ?>