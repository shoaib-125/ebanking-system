

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Loan History')); ?></h4>
                        </div>
                        <?php if(Session::has('success')): ?>
                           <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-header">
                                <h5><?php echo e(__('Loan Information')); ?></h5>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col"><?php echo e(__('Name')); ?></th>
                                        <th scope="col"><?php echo e(__('Package')); ?></th>
                                        <th scope="col"><?php echo e(__('Days')); ?></th>
                                        <th scope="col"><?php echo e(__('Charge')); ?></th>
                                        <th scope="col"><?php echo e(__('Amount')); ?></th>
                                        <th scope="col"><?php echo e(__('Total')); ?></th>
                                        <th scope="col"><?php echo e(__('Status')); ?></th>
                                        <th scope="col"><?php echo e(__('Return')); ?></th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $loan_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $total = $row->amount + $row->charge;
                                    ?>
                                      <tr>
                                        <td><?php echo e($row->user->name); ?></td>
                                        <td><?php echo e($row->loanplan->name); ?></td>
                                        <td><?php echo e($row->days); ?></td>
                                        <td><?php echo e($row->charge); ?></td>
                                        <td><?php echo e($row->amount); ?></td>
                                        <td><?php echo e($total); ?></td>
                                        <?php if($row->status == 1): ?>
                                        <td>
                                            <span class="badge bg-info"><?php echo e(__('Approved')); ?></span>
                                        </td>
                                        <?php endif; ?>
                                        <?php if($row->status == 2): ?>
                                        <td>
                                            <span class="badge bg-danger"><?php echo e(__('Pending')); ?></span>
                                        </td>
                                        <?php endif; ?>
                                        <?php if($row->status == 0): ?>
                                        <td>
                                            <span class="badge bg-danger"><?php echo e(__('Rejected')); ?></span>
                                        </td>
                                        <?php endif; ?>
                                        <?php if($row->status == 3): ?>
                                        <td>
                                            <span class="badge bg-primary"><?php echo e(__('Loan Returned')); ?></span>
                                        </td>
                                        <?php endif; ?>
                                        <td>
                                         <a class="btn btn-primary btn-sm delete-confirm <?php echo e($row->status == 1 ? "" : "disabled"); ?>" href="javascript:void(0)" data-id=<?php echo e($row->id); ?>><?php echo e(__('Loan Return')); ?></a>
                                        </td>
                                        <!-- Delete Form -->
                                        <form class="d-none" id="delete_form_<?php echo e($row->id); ?>" action="<?php echo e(route('user.return.loan', $row->id)); ?>" method="GET">
                                        </form>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="float-right">
                                    <?php echo e($loan_history->links('vendor.pagination.bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/user/loan/loan_history.blade.php ENDPATH**/ ?>