

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Confirm Transfer')); ?></h4>
                        </div>
                        <div class="section-body">
                            <div class="container">
                                <div class="row">
                                        <div class="col-lg-8 offset-lg-2">
                                            <div class="card">
                                                <div class="card-body">
                                            <div class="form-group row mb-4">
                                                <div class="px-4">
                                                    <table class="table">
                                                        <tr>
                                                            <td><?php echo e(__('Bank Name')); ?></td>
                                                            <td><?php echo e($data->bank_name); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Branch')); ?></td>
                                                            <td><?php echo e($data->branch); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Account Holder Name')); ?></td>
                                                            <td><?php echo e($data->account_holder_name); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Account Number')); ?></td>
                                                            <td><?php echo e($data->account_no); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Currency Name')); ?></td>
                                                            <td><?php echo e($data->currency_name); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Currency Rate')); ?></td>
                                                            <td><?php echo e($data->currency_rate); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Amount (excluding charge)')); ?></td>
                                                            <td><?php echo e($data->usd); ?> (<?php echo e(__('USD')); ?>)</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Total Charge')); ?> </td>
                                                            <td><?php echo e($data->total_charge); ?> (<?php echo e(__('USD')); ?>)</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Amount (including charge)')); ?> </td>
                                                            <td><?php echo e($data->amount-$data->total_charge); ?> (<?php echo e(__('USD')); ?>)</td>
                                                        </tr>
                                                        <tr>
                                                            <td><?php echo e(__('Final Amount')); ?> </td>
                                                            <td><?php echo e($data->final_amount); ?> (<?php echo e($data->currency_name); ?>)</td>
                                                        </tr>
                                                    </table>
                                                    <form action="<?php echo e(route('user.transfer.otherbank.transferotp')); ?>" class="basicform" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" value="<?php echo e(route('user.transfer.otherbank.transferotpview')); ?>" class="redirectUrl">
                                                        <button type="submit" class="basicbtn btn btn-primary my-4 w-100" tabindex="4">
                                                            <?php echo e(__('Submit')); ?>

                                                        </button>
                                                    </form>
                                                </div>
                                            </div>  
                                           </div>
                                       </div>
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('frontend/assets/js/transfer/redirect.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/user/transfer/otherbankConfirm.blade.php ENDPATH**/ ?>