

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
              <div class="col-lg-4">
                <form method="get" action="<?php echo e(route('admin.loan.approved.search')); ?>">
                  <div class="input-group mb-2 col-12">
                     <input type="text" class="form-control" placeholder="Search..." name="q" autocomplete="off" value="">
                     <select class="form-control" name="type">
                        <option value="account_number"><?php echo e(__('Search By Account Number')); ?></option>
                     </select>
                     <div class="input-group-append">                                            
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                     </div>
                  </div>
                </form>
              </div>
              <div class="col-lg-8">
                <form method="get" action="<?php echo e(route('admin.loan.approved.search')); ?>">
                <input type="hidden" name="type" value="duration">
                <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <div class="col-lg-3 d-flex align-items-center">
                          <?php echo e(__('Start Date')); ?>

                       </div>
                       <div class="col-lg-9">
                          <input type="date" class="form-control" name="start_date">
                       </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <div class="col-lg-3 d-flex align-items-center">
                          <?php echo e(__('End Date')); ?> 
                       </div>
                       <div class="col-lg-9 input-group">
                          <input type="date" class="form-control" name="end_date">
                          <div class="input-group-append">                                            
                            <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                         </div>
                       </div>
                      </div>
                    </div>
                </div>
              </form>
            </div>
            </div>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                      <th><?php echo e(__('User Name')); ?></th>
                      <th><?php echo e(__('Package Name')); ?></th>
                      <th><?php echo e(__('Charge')); ?></th>
                      <th><?php echo e(__('Total Amount')); ?></th>
                      <th><?php echo e(__('Total Days')); ?></th>
                      <th><?php echo e(__('Status')); ?></th>
                      <th><?php echo e(__('View')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $loan_approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><a href="<?php echo e(url('/admin/users',$row->user->id)); ?>"><?php echo e($row->user->name); ?></a></td>
                      <td>
                       <?php echo e($row->loanplan->name); ?> 
                      </td>
                      <td><?php echo e($row->charge); ?></td>
                      <td>
                        <?php echo e($row->amount); ?>

                      </td>
                      <td><?php echo e($row->days); ?></td>
                      <?php if($row->status == 2): ?> 
                      <td><span  class="badge badge-warning"><?php echo e(__('Pending')); ?></span></td>
                      <?php endif; ?>
                      <?php if($row->status == 1): ?> 
                      <td ><span  class="badge badge-success"><?php echo e(__('Approved')); ?></span></td>
                      <?php endif; ?>
                      <?php if($row->status == 0): ?> 
                      <td><span  class="badge badge-danger"><?php echo e(__('Rejected')); ?></span></td>
                      <?php endif; ?>
                      <td>
                        <a class="btn btn-primary" href="<?php echo e(route('admin.loan.request.show', $row->id)); ?>"><i class="fa fa-eye"></i><?php echo e(__('View')); ?></a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
              <?php echo e($loan_approved->links('vendor.pagination.bootstrap-4')); ?>

          </div>
       </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/loanmanagement/approved.blade.php ENDPATH**/ ?>