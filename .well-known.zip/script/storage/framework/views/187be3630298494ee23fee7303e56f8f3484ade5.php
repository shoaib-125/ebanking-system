

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Manage Other Banks'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-lg-6">
                    <h4><?php echo e(__('Others Bank List')); ?></h4>
                </div>
                <div class="col-lg-6">
                    <div class="add-new-btn">
                        <a href="<?php echo e(route('admin.others-bank.create')); ?>" class="btn btn-primary float-right"><?php echo e(__('Add New Bank')); ?></a>
                    </div>
                </div>
            </div>
            <?php if(Session::has('message')): ?>
              <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                      <th>
                        <div class="custom-checkbox custom-control">
                          <input type="checkbox" data-checkboxes="mygroup" data-checkbox-role="dad" class="custom-control-input" id="checkbox-all">
                          <label for="checkbox-all" class="custom-control-label">&nbsp;</label>
                        </div>
                      </th>
                      <th><?php echo e(__('Bank Name')); ?></th>
                      <th><?php echo e(__('Country')); ?></th>
                      <th><?php echo e(__('Maximum Limit')); ?></th>
                      <th><?php echo e(__('Status')); ?></th>
                      <th><?php echo e(__('Created At')); ?></th>
                      <th><?php echo e(__('Action')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <div class="custom-checkbox custom-control">
                          <input type="checkbox" data-checkboxes="mygroup" class="custom-control-input" id="checkbox-1">
                          <label for="checkbox-1" class="custom-control-label">&nbsp;</label>
                        </div>
                      </td>
                      <td><?php echo e($bank->name); ?></td>
                      <td><?php echo e($bank->country->title); ?></td>
                      <td class="align-middle">
                        <?php echo e($bank->max_amount); ?>

                      </td>
                      <td>
                        <?php echo e($bank->status == 0 ? 'Inactive' : 'Active'); ?>

                      </td>
                      <td><?php echo e($bank->created_at); ?></td>
                      <td>
                        <div class="dropdown d-inline">
                          <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(__('Action')); ?>

                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item has-icon" href="<?php echo e(route('admin.others-bank.show', $bank->id)); ?>"><i class="fa fa-eye"></i><?php echo e(__('View')); ?></a>
                            <a class="dropdown-item has-icon" href="<?php echo e(route('admin.others-bank.edit', $bank->id)); ?>"><i class="fa fa-edit"></i><?php echo e(__('Edit')); ?></a>

                            <a class="dropdown-item has-icon delete-confirm" href="javascript:void(0)" data-id=<?php echo e($bank->id); ?>><i class="fa fa-trash"></i><?php echo e(__('Delete')); ?></a>

                            <form class="d-none" id="delete_form_<?php echo e($bank->id); ?>" action="<?php echo e(route('admin.others-bank.destroy', $bank->id)); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                            </form>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              
                <?php echo e($banks->links('vendor.pagination.bootstrap-4')); ?>

            </div>
          </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/otherbank/index.blade.php ENDPATH**/ ?>