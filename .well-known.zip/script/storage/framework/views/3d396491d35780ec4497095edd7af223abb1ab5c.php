

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Ownbank Transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
              <div class="col-lg-4">
                <form method="get" action="<?php echo e(route('admin.ownbank.search')); ?>">
                  <div class="input-group mb-2 col-12">
                     <input type="text" class="form-control" placeholder="Search..." name="q" autocomplete="off" value="">
                     <select class="form-control" name="type">
                        <option value="account_number"><?php echo e(__('Search By Account Number')); ?></option>
                        <option value="trx"><?php echo e(__('Search By Trx')); ?></option>
                     </select>
                     <div class="input-group-append">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i>
                        </button>
                     </div>
                  </div>
                </form>
              </div>
              <div class="col-lg-8">
                <form method="get" action="<?php echo e(route('admin.ownbank.search')); ?>">
                <input type="hidden" name="type" value="duration">
                <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <div class="col-lg-3 d-flex align-items-center">
                          <?php echo e(__('Start Date')); ?>

                       </div>
                       <div class="col-lg-9">
                          <input type="date" class="form-control" name="start_date">
                       </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <div class="col-lg-3 d-flex align-items-center">
                         <?php echo e(__(' End Date ')); ?>

                       </div>
                       <div class="col-lg-9 input-group">
                          <input type="date" class="form-control" name="end_date">
                          <div class="input-group-append">                                            
                            <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                         </div>
                       </div>
                      </div>
                    </div>
                </div>
              </form>
            </div>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                      <th><?php echo e(__('User')); ?></th>
                      <th><?php echo e(__('Account')); ?></th>
                      <th><?php echo e(__('Trx')); ?></th>
                      <th><?php echo e(__('Amount')); ?></th>
                      <th><?php echo e(__('Info')); ?></th>
                      <th><?php echo e(__('Date')); ?></th>
                      <th><?php echo e(__('View')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><a href="<?php echo e(url('/admin/users',$row->user->id)); ?>"><?php echo e($row->user->name); ?></a></td>
                      <td><a href="<?php echo e(url('/admin/users',$row->user->id)); ?>"><?php echo e($row->user->account_number); ?></a></td>
                      <td><?php echo e($row->trxid); ?></td>
                      <td><?php echo e($row->amount); ?></td>
                      <td><?php echo e($row->info); ?></td>
                      <td><?php echo e(date('d-m-Y', strtotime($row->created_at))); ?></td>
                      <td>  
                        <a title="view" class="btn btn-info btn-sm" href="<?php echo e(route('admin.all.transaction.view', $row->id)); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <?php echo e($transaction->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/transaction/ownbank.blade.php ENDPATH**/ ?>