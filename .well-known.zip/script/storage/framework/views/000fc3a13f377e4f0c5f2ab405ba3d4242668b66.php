

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Support Tickets'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <div class="card-body">
          <div class="tickets">
            <div class="ticket-items" id="ticket-items">
            <?php $__empty_1 = true; $__currentLoopData = $supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="ticket-item mb-3 position-relative" data-id="<?php echo e($support->id); ?>">
              <div class="ticket-title">
                <h4><?php echo e($support->title); ?></h4>
              </div>
              <div class="ticket-desc">
                <div class="user"><?php echo e($support->user->name); ?></div>
                <div class="bullet"></div>
                <div class="date"><?php echo e($support->created_at->diffForHumans()); ?></div>
              </div>
                <a class="btn btn-danger delete-chat" href="javascript:void(0)" data-id=<?php echo e($support->id); ?>><i class="fa fa-trash"></i></a>
                <!-- Delete Form -->
                <form class="d-none" id="delete_form_<?php echo e($support->id); ?>" action="<?php echo e(route('admin.support.destroy', $support->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <h6><?php echo e(__('No support ticket found!')); ?></h6>
            <?php endif; ?>  
            <?php echo e($supports->links('vendor.pagination.bootstrap-4')); ?>

          </div>
          <div class="ticket-content position-relative <?php echo e((count($supports) == 0) ? 'd-none' : ''); ?>">
            <span class="loader">
              <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="">
            </span>
            <select name="" id="turnoff" class="ml-3">
              <option><?php echo e(__('Turn off?')); ?></option>
              <option value="0"><?php echo e(__('OFF')); ?></option>
              <option value="1"><?php echo e(__('Active')); ?></option>
            </select>
            <div id="msgbox" class="position-relative">
             
            </div>
            <div class="ticket-form">
              <form method="POST" class="basicform_with_reload" id="ticketform" action="<?php echo e(route('admin.support.update', $support->id)); ?>"> 
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                  <div class="form-row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="form-group">
                      <label><?php echo e(__('Comment')); ?></label>
                      <textarea name="comment" class="form-control" rows="1"></textarea>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                      <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn"><?php echo e(__('Submit')); ?></button>
                  </div>
                </div>
            </form> 
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<input type="hidden" value="<?php echo e(route('admin.support.info')); ?>" id="support_url">
<input type="hidden" value="<?php echo e(route("admin.support.status")); ?>" id="support_status_url">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/admin/assets/js/support.js?v=1.0.1.0')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/support/index.blade.php ENDPATH**/ ?>