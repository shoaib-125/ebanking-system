

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('Backend/admin/assets/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-9">      
		<div class="card">
			<div class="card-body">
				<h4><?php echo e(__('Add Admin')); ?></h4>
				<form method="post" action="<?php echo e(route('admin.admin.store')); ?>" class="basicform_with_reset">
					<?php echo csrf_field(); ?>
					<div class="pt-20">
						<div class="form-group">
							<label for="name"><?php echo e(__('Name')); ?></label>
							<input type="text" required class="form-control" name="name" placeholder="Enter admin name" >
						</div>
						
						<div class="form-group">
							<label for="email"><?php echo e(__('Email')); ?></label>
							<input type="email" required class="form-control" name="email" placeholder="Enter email" >
						</div>
						
						<div class="form-group">
							<label for="email"><?php echo e(__('Phone')); ?></label>
							<input type="number" required class="form-control" name="phone" placeholder="Enter phone" >
						</div>

						<div class="form-group">
							<label for="password"><?php echo e(__('Password')); ?></label>
							<input type="password" required class="form-control" name="password" placeholder="Enter password" >
						</div>
						<div class="form-group">
							<label for="password"><?php echo e(__('Confirm Password')); ?></label>
							<input type="password" required class="form-control" name="password_confirmation" placeholder="Enter password" >
						</div>

					     <div class="form-group">
                            <label ><?php echo e(__('Assign Roles')); ?></label>
                            <select required name="roles[]" id="roles" class="form-control select2" multiple>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
					</div>
				</div>
			</div>
		</div>
	<div class="col-lg-3">
		<div class="single-area">
			<div class="card">
				<div class="card-body">
					<div class="btn-publish">
						<button type="submit" class="btn btn-primary col-12 basicbtn"><i class="fa fa-save"></i> <?php echo e(__('Save')); ?></button>
					</div>
				</div>
			</div>
		</div>	
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('Backend/admin/assets/js/select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/admin/create.blade.php ENDPATH**/ ?>