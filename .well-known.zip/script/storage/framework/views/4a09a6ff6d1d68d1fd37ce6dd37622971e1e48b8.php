<?php echo e($slot); ?>

<?php /**PATH /home/gotodev/public_html/ebanking/script/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>