


<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Transfer')); ?></h4>
                        </div>
                        <div class="card">
                            <div class="card-body">
                               <form action="<?php echo e(route('user.transfer.ownbank.confirm')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Account')); ?></label>
                                                <input type="text" name="account_no" value="<?php echo e(old('account_no')); ?>" class="<?php echo e(Session::has('account_err') ? 'is-invalid' : ''); ?> form-control" placeholder="<?php echo e(__('Account Number')); ?>">
                                            </div>
                                            
                                            <?php if(Session::has('account_err')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e(Session::get('account_err')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Amount')); ?></label>
                                                <input type="number" name="amount" class="<?php echo e(Session::has('error') ? 'is-invalid' : ''); ?> form-control" value="<?php echo e(old('amount')); ?>" placeholder="<?php echo e(__('Amount')); ?>">
                                            </div>
                                            <?php if(Session::has('error')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e(Session::get('error')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12 text-center mt-3">
                                            <div class="button-btn">
                                                <button type="submit" class="d-block w-100"><?php echo e(__('Submit')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                               </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/user/transfer/ownbank.blade.php ENDPATH**/ ?>