

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Transaction Details View')); ?></h4>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <?php if($transaction->type == 'otherbank_transfer'): ?>
                                <?php 
                                $otherbank_info = json_decode($transaction->otherbank->info)
                                ?>
                                <tr>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <td><?php echo e(__('From')); ?></td>
                                                <td><?php echo e(__('To')); ?></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo e(__('Account Number')); ?>: <?php echo e($transaction->otherbank->user->account_number); ?></td>
                                                <td><?php echo e(__('Account Number')); ?>:  <?php echo e($otherbank_info->account_number); ?></td>
                                                
                                            </tr>
                                            <tr>
                                                <td><?php echo e(__('Account Holder Name')); ?> : <?php echo e($transaction->otherbank->user->name); ?></td>
                                                <td><?php echo e(__('Account Holder Name')); ?> : <?php echo e($otherbank_info->account_holder_name); ?></td>
                                                
                                            </tr>   
                                            <tr>
                                                <td><?php echo e(__('Branch (to)')); ?> : <?php echo e($otherbank_info->branch); ?></td>
                                                <td></td>
                                            </tr> 
                                        </tbody>
                                    </table>
                                </tr>   
                            <?php endif; ?>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('Title')); ?></th>
                                            <th><?php echo e(__('Details')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e(__('Trx ID')); ?></td>
                                            <td><?php echo e($transaction->trxid); ?></td>
                                        </tr>

                                        <tr>
                                            <td><?php echo e(__('Amount (USD)')); ?></td>
                                            <td><?php echo e($transaction->amount); ?></td>
                                        </tr>

                                        <tr>
                                            <td><?php echo e(__('Balance (USD)')); ?></td>
                                            <td><?php echo e($transaction->balance); ?></td>
                                        </tr>

                                        <tr>
                                            <td><?php echo e(__('Fee')); ?></td>
                                            <td><?php echo e($transaction->fee); ?></td>
                                        </tr>

                                        <tr>
                                            <td><?php echo e(__('Status')); ?></td>
                                            <td><?php echo e($transaction->status == 1 ? 'Success' : 'Pending'); ?>

                                            </td>
                                        </tr>

                                        <tr>
                                            <td><?php echo e(__('Info')); ?></td>
                                            <td><?php echo e($transaction->info); ?></td>
                                        </tr>

                                        <tr>
                                            <td><?php echo e(__('Type')); ?></td>
                                            <td><?php echo e(ucwords(str_replace("_", " ", $transaction->type))); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/user/transaction/view.blade.php ENDPATH**/ ?>