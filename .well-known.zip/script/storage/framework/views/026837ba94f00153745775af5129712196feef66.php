

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
              <h4><?php echo e(__('Currency Create')); ?></h4>
            </div>
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <strong><?php echo e(__('woops!')); ?></strong> <?php echo e(__('There were some problems with your input.')); ?><br><br>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.currency.store')); ?>" class="basicform_with_reset">
              <?php echo csrf_field(); ?>
              <div class="card-body">              
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Country Name')); ?></label>
                    <div class="col-sm-12 col-md-7">
                      <input type="text" class="form-control" placeholder="Title" required name="title">
                    </div>
                  </div>                  
                                   
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Rate')); ?></label>
                    <div class="col-sm-12 col-md-7">
                      <input type="number" step="any" class="form-control" placeholder="Rate" name="slug">
                    </div>
                  </div>
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Status')); ?></label>
                    <div class="col-sm-12 col-md-7">
                      <select name="status" class="form-control">
                        <option value="1"><?php echo e(__('Active')); ?></option>
                        <option value="0"><?php echo e(__('In-Active')); ?></option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Logo')); ?></label>
                    <div class="col-sm-12 col-md-7">
                      <input type="file" class="form-control" name="logo">
                    </div>
                  </div> 
                  <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                    <div class="col-sm-12 col-md-7">
                      <button type="submit" class="btn btn-primary btn-lg  basicbtn"><?php echo e(__('Submit')); ?></button>
                    </div>
                  </div>
              </div>
          </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/currency/create.blade.php ENDPATH**/ ?>