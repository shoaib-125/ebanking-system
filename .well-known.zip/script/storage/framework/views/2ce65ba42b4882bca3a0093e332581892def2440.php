<?php if(!empty($menus)): ?>
<div class="footer-menu-title">
	<h4><?php echo e($menus['title'] ?? ''); ?></h4>
</div>
<div class="footer-menu-content">
	<nav>
		<ul>
			<?php $__currentLoopData = $menus['menu'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<?php if(isset($row->children)): ?> 
			<li>
				<a href="#"><?php echo e($row->text); ?> <span class="iconify" data-icon="dashicons:arrow-down-alt2" data-inline="false"></span></a>

				<ul class="sub">
					<?php $__currentLoopData = $row->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childrens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo $__env->make('components.footer_menu.child', ['childrens' => $childrens], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</li>
			<?php else: ?>
			<li>
				<a href="<?php echo e(url($row->href)); ?>" <?php if(!empty($row->target)): ?> target="<?php echo e($row->target); ?>" <?php endif; ?>><?php echo e($row->text); ?></a>
			</li>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</ul>
	</nav>
</div>
<?php endif; ?>
<?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/components/footer_menu/parent.blade.php ENDPATH**/ ?>