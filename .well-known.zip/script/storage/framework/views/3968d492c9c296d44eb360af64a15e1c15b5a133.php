

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12">
      <div class="card card-statistic-2">
        <div class="card-stats">
          <div class="card-stats-title"><?php echo e(__('Pending Issues')); ?>

          </div>
          <div class="card-stats-items">
            <div class="card-stats-item">
              <div class="card-stats-item-count" id="pening_support"><span class="loader">
                <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
              </span></div>
              <div class="card-stats-item-label"><?php echo e(__('Open Support')); ?></div>
            </div>
            <div class="card-stats-item">
              <div class="card-stats-item-count" id="pending_withdraw"><span class="loader">
                <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
              </span></div>
              <div class="card-stats-item-label"><?php echo e(__('Pending Withdraw')); ?></div>
            </div>
            <div class="card-stats-item">
              <div class="card-stats-item-count" id="pending_deposit"><span class="loader">
                <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
              </span></div>
              <div class="card-stats-item-label"><?php echo e(__('Pending Deposit')); ?></div>
            </div>
          </div>
        </div>
        <div class="card-icon shadow-primary bg-primary">
          <i class="fas fa-archive"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4><?php echo e(__('Total Issues')); ?></h4>
          </div>
          <div class="card-body" id="total_issue">
            <span class="loader">
              <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
            </span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12">
      <div class="card card-statistic-2">
        <div class="card-chart">
          <canvas id="deposit_transactions" height="80"></canvas>
        </div>
        <div class="card-icon shadow-primary bg-primary">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4><?php echo e(__('Deposit Transactions')); ?> - <?php echo e(date('Y')); ?></h4>
          </div>
          <div class="card-body" id="deposit_sum">
            <span class="loader">
              <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
            </span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12">
      <div class="card card-statistic-2">
        <div class="card-chart">
          <canvas id="all_transactions" height="80"></canvas>
        </div>
        <div class="card-icon shadow-primary bg-primary">
          <i class="fas fa-shopping-bag"></i>
        </div>
        <div class="card-wrap">
          <div class="card-header">
            <h4><?php echo e(__('All Transactions')); ?> - <?php echo e(date('Y')); ?></h4>
          </div>
          <div class="card-body" id="all_transaction_count">
            <span class="loader">
              <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
            </span>
          </div>
        </div>
      </div>
    </div>
    <div class="col-12">
      <div class="section">
        <h2 class="section-title m-0 mb-3"><?php echo e(__('Users')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="far fa-user"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Users')); ?></h4>
                        </div>
                        <div class="card-body" id="total_users">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-success">
                        <i class="fas fa-circle"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Active Users')); ?></h4>
                        </div>
                        <div class="card-body" id="active_users">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>      
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                      <div class="card card-statistic-1 mb-0">
                        <div class="card-icon bg-success">
                          <i class="far fa-circle"></i>
                        </div>
                        <div class="card-wrap position-relative">
                          <div class="card-header">
                            <h4><?php echo e(__('Email Verified')); ?></h4>
                          </div>
                          <div class="card-body" id="email_verified">
                            <span class="loader">
                              <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>  
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                      <div class="card card-statistic-1 mb-0">
                        <div class="card-icon bg-success">
                          <i class="far fa-circle"></i>
                        </div>
                        <div class="card-wrap position-relative">
                          <div class="card-header">
                            <h4><?php echo e(__('Phone Verified')); ?></h4>
                          </div>
                          <div class="card-body" id="phone_verified">
                            <span class="loader">
                              <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>           
                </div>
            </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Users Finance Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Deposit (users)')); ?></h4>
                        </div>
                        <div class="card-body" id="total_deposit">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Fix Deposit Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-primary">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Number of Deposit')); ?></h4>
                      </div>
                      <div class="card-body" id="number_of_fixed_deposit">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-warning">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('In queue')); ?></h4>
                      </div>
                      <div class="card-body" id="fixed_deposit_queue">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-success">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Completed')); ?></h4>
                      </div>
                      <div class="card-body" id="fixed_deposit_completed">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-danger">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('In queue')); ?></h4>
                      </div>
                      <div class="card-body" id="fixed_deposit_cancelled">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-primary">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Total Deposit')); ?></h4>
                      </div>
                      <div class="card-body" id="fixed_deposit_amount">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-primary">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Total Return')); ?></h4>
                      </div>
                      <div class="card-body" id="fixed_deposit_return">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-primary">
                      <i class="fas fa-money-check-alt"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Total Interest')); ?></h4>
                      </div>
                      <div class="card-body" id="fixed_deposit_interest">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Loans Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-warning">
                      <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Loan Pending')); ?></h4>
                      </div>
                      <div class="card-body" id="loan_pending">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>                  
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-primary">
                      <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Loan Queue')); ?></h4>
                      </div>
                      <div class="card-body" id="loan_queue">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>                  
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-primary">
                      <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Loan Given')); ?></h4>
                      </div>
                      <div class="card-body" id="loan_given">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>                  
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <div class="card card-statistic-1 mb-0">
                    <div class="card-icon bg-success">
                      <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="card-wrap position-relative">
                      <div class="card-header">
                        <h4><?php echo e(__('Loan Complete')); ?></h4>
                      </div>
                      <div class="card-body" id="loan_complete">
                        <span class="loader">
                          <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>                  
              </div>
          </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Deposit Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="fas fa-money-check"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Deposits')); ?></h4>
                        </div>
                        <div class="card-body" id="total_deposit_number">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-success">
                        <i class="fas fa-money-check"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Deposit Amount')); ?></h4>
                        </div>
                        <div class="card-body" id="total_deposit_amount">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-warning">
                        <i class="fas fa-money-check"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Deposit Charge')); ?></h4>
                        </div>
                        <div class="card-body" id="total_deposit_charge">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Other Bank Transaction Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Number of Deposit')); ?></h4>
                        </div>
                        <div class="card-body" id="other_bank_total">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-success">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Approved')); ?></h4>
                        </div>
                        <div class="card-body" id="other_bank_approved">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-danger">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Rejected')); ?></h4>
                        </div>
                        <div class="card-body" id="other_bank_reject">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-warning">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Pending')); ?></h4>
                        </div>
                        <div class="card-body" id="other_bank_pending">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Amount')); ?></h4>
                        </div>
                        <div class="card-body" id="other_bank_amount">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-success">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Charge')); ?></h4>
                        </div>
                        <div class="card-body" id="other_bank_charge">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Withdraw Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Withdraw')); ?></h4>
                        </div>
                        <div class="card-body" id="withdraw_total">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-warning">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Pending')); ?></h4>
                        </div>
                        <div class="card-body" id="withdraw_pending">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-danger">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Rejected')); ?></h4>
                        </div>
                        <div class="card-body" id="withdraw_reject">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-warning">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Charge')); ?></h4>
                        </div>
                        <div class="card-body" id="withdraw_charge">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="section">
        <h2 class="section-title"><?php echo e(__('Billing Statistics')); ?></h2>
        <div class="card">
          <div class="card-body">
              <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1 mb-0">
                      <div class="card-icon bg-primary">
                        <i class="fas fa-money-check-alt"></i>
                      </div>
                      <div class="card-wrap position-relative">
                        <div class="card-header">
                          <h4><?php echo e(__('Total Bill')); ?></h4>
                        </div>
                        <div class="card-body" id="bill_total">
                          <span class="loader">
                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                          </span>
                        </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1 mb-0">
                  <div class="card-icon bg-warning">
                    <i class="fas fa-money-check-alt"></i>
                  </div>
                  <div class="card-wrap position-relative">
                    <div class="card-header">
                      <h4><?php echo e(__('Pending')); ?></h4>
                    </div>
                    <div class="card-body" id="bill_pending">
                      <span class="loader">
                        <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1 mb-0">
                  <div class="card-icon bg-success">
                    <i class="fas fa-money-check-alt"></i>
                  </div>
                  <div class="card-wrap position-relative">
                    <div class="card-header">
                      <h4><?php echo e(__('Complete')); ?></h4>
                    </div>
                    <div class="card-body" id="bill_complete">
                      <span class="loader">
                        <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=50>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>   
<input type="hidden" id="my_url" value="<?php echo e(route("admin.dashboard.statistics")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/admin/assets/js/sparkline.js')); ?>"></script>
<script src="<?php echo e(asset('backend/admin/assets/js/chart.js')); ?>"></script>
<script src="<?php echo e(asset('backend/admin/assets/js/page/index.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>