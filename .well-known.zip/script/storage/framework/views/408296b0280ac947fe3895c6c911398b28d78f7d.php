

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'All Deposit List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-lg-6">
                    <form method="get" action="<?php echo e(route('admin.deposit.search')); ?>">
                    
                      <div class="input-group mb-2 col-12">
                         <input type="text" class="form-control" placeholder="Search..." name="q" autocomplete="off" value="">
                         <select class="form-control" name="type">
                            <option value="account_number"><?php echo e(__('Search By Account Number')); ?></option>
                            <option value="trx"><?php echo e(__('Search By Trx')); ?></option>
                         </select>
                         <div class="input-group-append">                                            
                            <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                         </div>
                      </div>
                   </form>
                  </div>
                <div class="col-lg-6">
                    <div class="add-new-btn">
                        <a href="<?php echo e(route('admin.deposit.create')); ?>" class="btn btn-primary float-right"><?php echo e(__('Add New Deposit')); ?></a>
                    </div>
                </div>
                <div class="col-lg-12">
                  <?php if(Session::has('message')): ?>
                    <p class="alert alert-danger">
                        <?php echo e(Session::get('message')); ?>

                    </p>
                  <?php endif; ?>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                      
                      <th><?php echo e(__('Trx')); ?></th>
                      <th><?php echo e(__('User')); ?></th>
                      <th><?php echo e(__('Account')); ?></th>
                      <th><?php echo e(__('Payment Gateway')); ?></th>
                      <th><?php echo e(__('Amount')); ?></th>
                      <th><?php echo e(__('Charge')); ?></th>
                      <th><?php echo e(__('Status')); ?></th>
                      <th><?php echo e(__('Action')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                     
                      <td><?php echo e($deposit->trx); ?></td>
                      <td class="align-middle"><a href="<?php echo e(route('admin.users.show', $deposit->user->id)); ?>"> <?php echo e($deposit->user->name); ?></a> </td>
                      <td> <?php echo e($deposit->user->account_number); ?></td>
                      <td><?php echo e($deposit->getway->name); ?></td>
                      <td><?php echo e($deposit->amount); ?></td>
                      <td><?php echo e($deposit->charge); ?></td>
                      <td>
                        <?php if($deposit->status == 1): ?>
                          <span class="badge badge-success"><?php echo e(__('Success')); ?></span>
                        <?php elseif($deposit->status == 0): ?>
                          <span class="badge badge-danger"><?php echo e(__('Cancelled')); ?></span>
                        <?php else: ?> 
                          <span class="badge badge-warning"><?php echo e(__('Pending')); ?></span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if($deposit->status != 0): ?>
                        <div class="dropdown d-inline">
                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(__('Action')); ?>

                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item has-icon delete-confirm" href="javascript:void(0)" data-id=<?php echo e($deposit->id); ?>><i class="fa fa-trash"></i><?php echo e(__('Cancel')); ?></a>
                            <!-- Delete Form -->
                            <form class="d-none" id="delete_form_<?php echo e($deposit->id); ?>" action="<?php echo e(route('admin.deposit.update', $deposit->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            </form>
                          </div>
                        </div>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
              <?php echo e($deposits->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/deposits/index.blade.php ENDPATH**/ ?>