

<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('backend/admin/assets/css/summernote/summernote-bs4.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4><?php echo e(__('Counter Section Update')); ?></h4>
            </div>
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <strong><?php echo e(__('Whoops!')); ?></strong> <?php echo e(__('There were some problems with your input.')); ?><br><br>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.counter.update', $counter_data->id)); ?>" class="basicform">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>
              <?php
                $info = json_decode($counter_data->value);
              ?>
              <div class="card-body">
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Happy Customers Counter')); ?></label>
                        <input type="text" class="form-control" placeholder="Happy Customers Counter" required name="happy_customers_no" value="<?php echo e($info->happy_customers_no); ?>">
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-group">
                          <label><?php echo e(__('Happy Customers Title')); ?></label>
                          <input type="text" class="form-control" placeholder="Happy Customers Title" required name="happy_customers_title" value="<?php echo e($info->happy_customers_title); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Years in banking Counter')); ?></label>
                        <input type="text" class="form-control" placeholder="Years in banking Counter" required name="year_banking_no" value="<?php echo e($info->year_banking_no); ?>">
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-group">
                          <label><?php echo e(__('Years in banking Title')); ?></label>
                          <input type="text" class="form-control" placeholder="Years in banking Title" required name="year_banking_title" value="<?php echo e($info->year_banking_title); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Our branches Counter')); ?></label>
                        <input type="text" class="form-control" placeholder="Our branches Counter" required name="our_branches_no" value="<?php echo e($info->our_branches_no); ?>">
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-group">
                          <label><?php echo e(__('Our branches Title')); ?></label>
                          <input type="text" class="form-control" placeholder="Our branches Title" required name="our_branches_title" value="<?php echo e($info->our_branches_title); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Successfully works Counter')); ?></label>
                        <input type="text" class="form-control" placeholder="Successfully works Counter" required name="successfully_work_no" value="<?php echo e($info->successfully_work_no); ?>">
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-group">
                          <label><?php echo e(__('Successfully works Title')); ?></label>
                          <input type="text" class="form-control" placeholder="Successfully works Title" required name="successfully_work_title" value="<?php echo e($info->successfully_work_title); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn"><?php echo e(__('Update')); ?></button>
                  </div>
                </div>
              </div>
          </form>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/admin/counter/counter_index.blade.php ENDPATH**/ ?>