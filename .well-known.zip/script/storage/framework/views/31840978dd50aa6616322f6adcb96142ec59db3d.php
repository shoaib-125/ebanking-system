<footer class="main-footer">
    <div class="footer-left">
      Copyright &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> Develop By <a href="<?php echo e(url('/')); ?>/"><?php echo e(env('APP_NAME')); ?></a>
    </div>
    <div class="footer-right">
      1.0
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/layouts/backend/partials/footer.blade.php ENDPATH**/ ?>