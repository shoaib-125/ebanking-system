

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Bill Request')); ?></h4>
                        </div>
                        <div class="card">
                            <div class="card-body">
                               <form id="bill" action="<?php echo e(route('user.bill.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Email')); ?></label>
                                                <input type="email" value="<?php echo e(old('email')); ?>" name="email" class="form-control <?php echo e(Session::has('error') ? 'is-invalid' : ''); ?>" placeholder="<?php echo e(__('Enter Email Address')); ?>">
                                            </div>
                                            <?php if(Session::has('error')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e(Session::get('error')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Title')); ?></label>
                                                <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" placeholder="<?php echo e(__('Enter Your Title')); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Description')); ?></label>
                                                <textarea class="form-control" name="description" id="" cols="30" rows="5" placeholder="<?php echo e(__('Description')); ?>"><?php echo e(old('description')); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Amount (USD)')); ?></label>
                                                <input type="number" value="<?php echo e(old('amount')); ?>" name="amount" class="form-control" placeholder="<?php echo e(__('Amount')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12 text-center mt-3">
                                            <div class="button-btn">
                                                <button type="submit" class="basicbtn d-block w-100"><?php echo e(__('Submit')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                               </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gotodev/public_html/ebanking/script/resources/views/user/bill/create.blade.php ENDPATH**/ ?>