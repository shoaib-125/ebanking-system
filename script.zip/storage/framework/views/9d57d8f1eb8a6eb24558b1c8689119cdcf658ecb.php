<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
          <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(env('APP_NAME')); ?></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
          <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(Str::limit(env('APP_NAME'),2)); ?></a>
        </div>
        <ul class="sidebar-menu">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.index')): ?>
          <li class="<?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> <span><?php echo e(__('Dashboard')); ?></span></a>
          </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction')): ?>
          <!--- Transaction Modules --->
          <li class="menu-header"><?php echo e(__('Withdraw & Transactions')); ?></li>
          
          <li class="nav-item dropdown <?php echo e(Request::is('admin/bank_withdraw*') ? 'show active' : ''); ?> ">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-university"></i> <span><?php echo e(__('Bank Withdraw')); ?></span></a>
            <ul class="dropdown-menu">
             
              <li><a class="nav-link" href="<?php echo e(route('admin.bank_transaction_approved')); ?>"><?php echo e(__('Approved')); ?></a></li>
             
             
              <li><a class="nav-link" href="<?php echo e(route('admin.bank_transaction_rejected')); ?>"><?php echo e(__('Rejected')); ?></a></li>
              
              <li><a class="nav-link" href="<?php echo e(route('admin.bank_transaction_request')); ?>"><?php echo e(__('Requests')); ?>

              </a></li>
            </ul>
          </li>
          
          <li class="nav-item dropdown <?php echo e(Request::is('admin/ownbank') ? 'show active' : ''); ?> ">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-university"></i> <span><?php echo e(__('Own Bank')); ?></span></a>
            <ul class="dropdown-menu">
              <li><a class="nav-link" href="<?php echo e(route('admin.ownbank.transactions')); ?>"><?php echo e(__('Own Bank Transaction')); ?></a></li>
            </ul>
          </li>

          <!--- ALl Transaction Modules --->
          <li class="nav-item dropdown <?php echo e(Request::is('admin/all/transaction') ? 'show active' : ''); ?>">
              <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-exchange-alt"></i> <span> <?php echo e(__('All Transactions')); ?></span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="<?php echo e(route('admin.all.transaction')); ?>"><?php echo e(__('Transactions List')); ?></a></li>
                </a>
              </li>
            </ul>
          </li>
          <?php endif; ?>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/e-currency*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-coins"></i> <span><?php echo e(__('E-currency')); ?></span></a>
            <ul class="dropdown-menu">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw.request.approved')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.approved_withdraw')); ?>"><?php echo e(__('Approved Withdraw')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw.request.rejected')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.rejected_withdraw')); ?>"><?php echo e(__('Rejected Withdraw')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw.request.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.withdraw_request')); ?>"><?php echo e(__('Withdraw Request')); ?></a></li>
              <?php endif; ?>
            </ul>
          </li>
          <!--- Loan Management Modules --->
          
          <li class="nav-item dropdown <?php echo e(Request::is('admin/loan*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-hand-holding-usd"></i> <span><?php echo e(__('Loan Management')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan.management.create')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.loan.create')); ?>"><?php echo e(__('Add New Package')); ?></a></li>
              <?php endif; ?>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan.management.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.loan.index')); ?>"><?php echo e(__('Loan Package List')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan.request.list')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.loan.request')); ?>"><?php echo e(__('Loan Request')); ?>

              </a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan.approved.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.loan.approved.index')); ?>"><?php echo e(__('Loan Request Approved')); ?>

              </a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan.management.returnlist')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.loan.return.index')); ?>"><?php echo e(__('Loan Return List')); ?>

              </a></li>
              <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan.rejected.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.loan.rejected.index')); ?>"><?php echo e(__('Loan Request Rejected')); ?>

              </a></li>
              <?php endif; ?>
            </ul>
          </li>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction')): ?>
          <li class="<?php echo e(Request::is('admin/all/bills') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.bills')); ?>" class="nav-link"><i class="fas fa-wallet"></i> <span><?php echo e(__('All Bills')); ?></span></a>
          </li>
          <?php endif; ?>

          <li class="menu-header"><?php echo e(__('Deposits')); ?></li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/deposit*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="far fa-money-bill-alt"></i> <span><?php echo e(__('Deposits')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.deposit.index')); ?>"><?php echo e(__('All Deposits')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit.complete')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.deposit.complete')); ?>"><?php echo e(__('Complete Deposit')); ?></a></li>
              <?php endif; ?>
            </ul>
          </li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/fixed-deposit*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="far fa-money-bill-alt"></i> <span> <?php echo e(__('Fixed Deposit')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fixeddeposit.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.fixed-deposit.index')); ?>"><?php echo e(__('All Plans')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fixeddeposit.request')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.fixed.deposit.request')); ?>"><?php echo e(__('In Queue')); ?>

              </a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fixeddeposit.complete.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.fixed.deposit.complete')); ?>"><?php echo e(__('Complete Deposit')); ?>

              </a></li>
              <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fixeddeposit.failed.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.fixed.deposit.failed')); ?>"><?php echo e(__('Rejected Deposit')); ?>

              </a></li>
              <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fixeddeposit.history.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.fixed.deposit.history')); ?>"><?php echo e(__('History')); ?>

              </a></li>
              <?php endif; ?>
            </ul>
          </li>
          <!--- Bank Deposit Modules --->
          <li class="nav-item dropdown <?php echo e(Request::is('admin/bank-deposit*') ? 'show active' : ''); ?> <?php echo e(Request::is('admin/bank_deposit')  ?  'show active' : ''); ?> <?php echo e(Request::is('admin/manual_gateway')  ?  'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-university"></i> <span><?php echo e(__('Bank Deposit')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit.manual.gateway.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.manual_gateway')); ?>"><?php echo e(__('Manual Gateway')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bank.deposit.approve')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.approve_manual_deposit')); ?>"><?php echo e(__('Approve Manual Deposit')); ?>

              </a></li>
              <?php endif; ?>

               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bank.deposit.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.bank_deposit.index')); ?>"><?php echo e(__('All Bank Deposits')); ?>

              </a></li>
              <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit.manual.gateway.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.reject_manual_deposit')); ?>"><?php echo e(__('Reject Manual Deposit')); ?>

              </a></li>
              <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deposit.manual.gateway.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.pending_manual_deposit')); ?>"><?php echo e(__('Pending Manual Deposit')); ?>

              </a></li>
              <?php endif; ?>
            </ul>
          </li>
          <!--- Branch Modules --->
          <li class="menu-header"><?php echo e(__('Bank')); ?></li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/branch*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-code-branch"></i> <span><?php echo e(__('Branch')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branch.create')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.branch.create')); ?>"><?php echo e(__('Branch Create')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branch.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.branch.index')); ?>"><?php echo e(__('Manage Branchs')); ?></a></li>
              <?php endif; ?>
            </ul>
          </li>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('otherbank.index')): ?>
          <li class="<?php echo e(Request::is('admin/others-bank') ? 'show active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.others-bank.index')); ?>"><i class="fas fa-university"></i> <span><?php echo e(__('Others Bank')); ?></span></a>
          </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('currency.index')): ?>
          <li class="<?php echo e(Request::is('admin/currency') ? 'show active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.currency.index')); ?>"><i class="fas fa-dollar-sign"></i> <span><?php echo e(__('Currency List')); ?></span></a>
          </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('country.index')): ?>
          <li class="<?php echo e(Request::is('admin/country') ? 'show active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.country.index')); ?>"><i class="fas fa-globe-americas"></i> <span><?php echo e(__('Country List')); ?></span></a>
          </li>
          <?php endif; ?>
            <li class="nav-item dropdown <?php echo e(Request::is('admin/withdraw*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-money-check-alt"></i> <span><?php echo e(__('Withdraw Method')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw.create')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.withdraw.create')); ?>"><?php echo e(__('Withdraw Method Create')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('withdraw.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.withdraw.index')); ?>"><?php echo e(__('Withdraw Method List')); ?></a></li>
              <?php endif; ?>
            </ul>
          </li>
         
        
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('option')): ?>
           <li class="menu-header"><?php echo e(__('Options')); ?></li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/option/ownbank*') ? 'show active' : ''); ?> <?php echo e(Request::is('admin/option/billcharge*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-funnel-dollar"></i> <span><?php echo e(__('Charges')); ?></span></a>
            <ul class="dropdown-menu">
              <li><a class="nav-link" href="<?php echo e(route('admin.option.ownbank.edit')); ?>"><?php echo e(__('Own Bank Charge')); ?></a></li>
              <li><a class="nav-link" href="<?php echo e(route('admin.option.billcharge.edit')); ?>"><?php echo e(__('Bill Charge')); ?></a></li>
            </ul>
          </li>
          <li class="<?php echo e(Request::is('admin/option/verification-settings') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.option.verification.edit')); ?>">
              <i class="fas fa-certificate"></i>
              <span><?php echo e(__('Verification Settings')); ?></span>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/gateway/automatic-gateway/index') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.deposit.automatic.gateway')); ?>"><i class="fas fa-wallet"></i> <span><?php echo e(__('Payment Gateway')); ?></span></a>
          </li>
          <li class="<?php echo e(Request::is('admin/option/twilio') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.option.twilio.edit')); ?>"><i class="fas fa-sms"></i> <span><?php echo e(__('SMS Settings')); ?></span></a>
          </li>
          <?php endif; ?>
          <!--- User management Modules --->
          <li class="menu-header"><?php echo e(__('Customer Management')); ?></li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/users*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-users"></i> <span><?php echo e(__('Users')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.create')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.users.create')); ?>"><?php echo e(__('Add User')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('All Users')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.verified')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.verified_users')); ?>"><?php echo e(__('Verified Users')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.banned')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.banded_users')); ?>"><?php echo e(__('Banded Users')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.unverified')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.email_unverified')); ?>"><?php echo e(__('Email Unverified')); ?></a></li>
              <li><a class="nav-link" href="<?php echo e(route('admin.mobile_unverified')); ?>"><?php echo e(__('Mobile Unverified')); ?></a></li>
              <?php endif; ?>
              
            </ul>
          </li>
          <!--- Website management Modules --->
          <li class="menu-header"><?php echo e(__('Website Management')); ?></li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/website*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-globe"></i> <span><?php echo e(__('Website')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('howitworks.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.howitworks.index')); ?>"><?php echo e(__('How it works')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.services.index')); ?>"><?php echo e(__('Manage Service')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.feedbacks.index')); ?>"><?php echo e(__('Manage Feedback')); ?></a></li>
              <?php endif; ?>
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('counter')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.counter.index')); ?>"><?php echo e(__('Manage Counter')); ?></a></li>
              <?php endif; ?>
             
            </ul>
          </li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/latest_news*') ? 'show active' : ''); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fab fa-blogger-b"></i> <span><?php echo e(__('Latest News')); ?></span></a>
            <ul class="dropdown-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.create')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.latest_news.create')); ?>"><?php echo e(__('Add New')); ?></a></li>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.index')): ?>
              <li><a class="nav-link" href="<?php echo e(route('admin.latest_news.index')); ?>"><?php echo e(__('All News')); ?>

              </a></li>
              <?php endif; ?>
            </ul>
          </li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/pages*') ? 'show active' : ''); ?>">
           <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-copy"></i> <span><?php echo e(__('Pages')); ?></span></a>
           <ul class="dropdown-menu">
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.create')): ?>
             <li><a class="nav-link" href="<?php echo e(route('admin.pages.create')); ?>"><?php echo e(__('Add New Page')); ?></a></li>
             <?php endif; ?>
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('page.index')): ?>
             <li><a class="nav-link" href="<?php echo e(route('admin.pages.index')); ?>"><?php echo e(__('All Pages')); ?></a></li>
             <?php endif; ?>
           </ul>
         </li>
         <li class="nav-item dropdown <?php echo e(Request::is('admin/investor*') ? 'show active' : ''); ?>">
          <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-industry"></i> <span><?php echo e(__('Investors')); ?></span></a>
          <ul class="dropdown-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('investors.create')): ?>
            <li><a class="nav-link" href="<?php echo e(route('admin.investor.create')); ?>"><?php echo e(__('Add New')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('investors.index')): ?>
            <li><a class="nav-link" href="<?php echo e(route('admin.investor.index')); ?>"><?php echo e(__('All Investors')); ?></a></li>
            <?php endif; ?>
          </ul>
        </li>
       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('title')): ?>
        <li class="<?php echo e(Request::is('admin/title*') ? 'show active' : ''); ?>">
          <a href="<?php echo e(route('admin.titles')); ?>" class="nav-link"><i class="fas fa-align-right"></i> <span><?php echo e(__('Titles And Descriptions')); ?></span></a>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support.index')): ?>
        <li class="<?php echo e(Request::is('admin/support') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('admin.support.index')); ?>" class="nav-link"><i class="fas fa-headset"></i> <span><?php echo e(__('Support')); ?></span></a>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('theme.settings')): ?>
        <li class="<?php echo e(Request::is('admin/theme/settings') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('admin.theme.settings')); ?>" class="nav-link"><i class="fas fa-columns"></i> <span><?php echo e(__('Theme Settings')); ?></span></a>
        </li>
        <?php endif; ?>
        <li class="menu-header"><?php echo e(__('Administrator')); ?></li>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/role') ? 'show active' : ''); ?> <?php echo e(Request::is('admin/admin') ? 'show active' : ''); ?>">
          <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-user-shield"></i> <span><?php echo e(__('Admins & Roles')); ?></span></a>
          <ul class="dropdown-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.list')): ?>
            <li><a class="nav-link" href="<?php echo e(route('admin.role.index')); ?>"><?php echo e(__('Roles')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.list')): ?>
            <li><a class="nav-link" href="<?php echo e(route('admin.admin.index')); ?>"><?php echo e(__('Admins')); ?></a></li>
            <?php endif; ?>
          </ul>
          <li class="nav-item dropdown <?php echo e(Request::is('admin/setting*') ? 'show active' : ''); ?> <?php echo e(Request::is('admin/menu') ? 'show active' : ''); ?>">
          <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-cogs"></i> <span><?php echo e(__('Settings')); ?></span></a>
          <ul class="dropdown-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system.settings')): ?>
            <li><a class="nav-link" href="<?php echo e(url('/admin/setting/env')); ?>"><?php echo e(__('System Environment')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('seo.settings')): ?>
            <li><a class="nav-link" href="<?php echo e(url('/admin/setting/seo')); ?>"><?php echo e(__('SEO Settings')); ?></a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu')): ?>
            <li><a class="nav-link" href="<?php echo e(route('admin.menu.index')); ?>"><?php echo e(__('Menu Settings')); ?></a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('language.index')): ?>
      <li class="<?php echo e(Request::is('admin/language') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.language.index')); ?>" class="nav-link"><i class="fas fa-language"></i> <span><?php echo e(__('Languages')); ?></span></a>
      </li>
      <?php endif; ?>
       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('phone.settings')): ?>
      <li class="<?php echo e(Request::is('admin/phone-settings*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('admin.phone-settings.index')); ?>" class="nav-link"><i class="fas fa-columns"></i> <span><?php echo e(__('Phone Settings')); ?></span></a>
      </li>
      <?php endif; ?>
    </ul>
  </aside>
</div><?php /**PATH D:\xampp\htdocs\files\script\resources\views/layouts/backend/partials/sidebar.blade.php ENDPATH**/ ?>