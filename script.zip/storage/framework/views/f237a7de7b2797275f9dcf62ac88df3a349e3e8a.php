

<?php $__env->startSection('content'); ?>
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Transaction History')); ?></h4>
                        </div>
                        <?php if(Session::has('message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(Session::get('message')); ?>

                        </p>
                        <?php endif; ?>
                        <form action="<?php echo e(route('user.transaction.search')); ?>">
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label><?php echo e(__('Start Date')); ?></label>
                                        <input type="date" class="form-control" name="start_date">
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label><?php echo e(__('End Date')); ?></label>
                                        <input type="date" class="form-control" name="end_date">
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="button-btn custom">
                                        <button type="submit"><?php echo e(__('Search')); ?></button>
                                    </div>
                                </div>  
                                <div class="col-lg-3 text-end">
                                    <div class="btn btn-primary custom">
                                        <a class="btn btn-primary" href="<?php echo e(route('user.transaction.pdf')); ?>"><?php echo e(__('PDF download')); ?></a>
                                    </div>
                                </div>  
                                <div class="col-3 text-end">
                                    
                                </div>                                  
                            </div>
                        </form>
                        <div class="card">
                            <div class="card-body table-responsive">
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col"><?php echo e(__('Trx ID')); ?></th>
                                        <th scope="col"><?php echo e(__('Amount')); ?></th>
                                        <th scope="col"><?php echo e(__('Balance')); ?></th>
                                        <th scope="col"><?php echo e(__('Fee')); ?></th>
                                        <th scope="col"><?php echo e(__('Status')); ?></th>
                                        <th scope="col"><?php echo e(__('Date / Time')); ?></th>
                                        <th scope="col"><?php echo e(__('Details')); ?></th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                            <td><?php echo e($key++); ?></td>
                                            <td><?php echo e($transaction->trxid); ?></td>
                                            <td><?php echo e($transaction->amount); ?></td>
                                            <td><?php echo e($transaction->balance); ?></td>
                                            <td><?php echo e($transaction->fee); ?></td>
                                            <td><?php echo e($transaction->status == 1 ? 'Success' :  ''); ?> <?php echo e($transaction->status == 2 ? 'Pending' : ''); ?></td>
                                            <td><?php echo e($transaction->created_at->isoFormat('LL')); ?>

                                            </td>
                                            <td>
                                                <a class="btn btn-primary" href="<?php echo e(route('user.transaction.view', $transaction->id)); ?>"><span class="iconify" data-icon="carbon:view-filled" data-inline="false"></span></a>
                                            </td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="float-right">
                                    <?php echo e($transactions->links('vendor.pagination.bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/user/transaction/history.blade.php ENDPATH**/ ?>