

<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('backend/admin/assets/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4><?php echo e(__('Withdraw Method Create')); ?></h4>
            </div>
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <strong><?php echo e(__('Whoops!')); ?></strong> <?php echo e(__('There were some problems with your input.')); ?><br><br>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.withdraw.store')); ?>" class="basicform_with_reset">
              <?php echo csrf_field(); ?>
              <div class="card-body">
                <div class="form-group">
                  <label><?php echo e(__('Method Name')); ?></label>
                  <input type="text" class="form-control" placeholder="Method Name" required name="name">
                </div>
                <div class="form-row">
                  <div class="col-lg-12 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Select Currency')); ?></label>
                        <select name="currency[]" class="form-control select2" multiple="multiple">
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                  </div>
                </div>
                <div class="form-row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label><?php echo e(__('Minimum Amount')); ?></label>
                        <input type="number" class="form-control" placeholder="Minimum Amount" required name="min_amount">
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo e(__('Maximum Amount')); ?></label>
                      <input type="number" class="form-control" placeholder="Maximum Amount" required name="max_amount">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label><?php echo e(__('Charge Type')); ?></label>
                  <select name="charge_type" class="form-control" id="charge_type">
                    <option value=""><?php echo e(__('Select charge type')); ?></option>
                    <option value="fixed"><?php echo e(__('Fixed')); ?></option>
                    <option value="percentage"><?php echo e(__('Percentage')); ?></option>
                    <option value="both"><?php echo e(__('Both')); ?></option>
                  </select>
                </div>
                <!--- Transaction Charge Fixed --->
              <div class="form-row">
                  <div class="transaction_fixed col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label><?php echo e(__('Fixed Amount')); ?></label>
                      <input type="number" class="form-control" name="fixed_charge" placeholder="Fixed Amount">
                     </div>
                  </div>
                <!--- Transaction Charge percentage --->
                <div class="transaction_percentage col-lg-6 col-md-6 col-sm-12">
                  <div class="form-group">
                   <label><?php echo e(__('Percentage Amount')); ?></label>
                   <input type="number" class="form-control" name="percent_charge" placeholder="Percentage Amount">
                  </div>
                </div>
              </div>
                <div class="form-row">
                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group">
                      <label><?php echo e(__('Status')); ?></label>
                      <select name="status" class="form-control">
                        <option value=""><?php echo e(__('Select Status')); ?></option>
                        <option value="1"><?php echo e(__('Active')); ?></option>
                        <option value="0"><?php echo e(__('Deactive')); ?></option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn"><?php echo e(__('Submit')); ?></button>
                  </div>
                </div>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('backend/admin/assets/js/select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/withdraw/create.blade.php ENDPATH**/ ?>