

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Manage Fixed Deposit Plans'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-lg-6">
               
                </div>
                <div class="col-lg-6">
                    <div class="add-new-btn">
                        <a href="<?php echo e(route('admin.fixed-deposit.create')); ?>" class="btn btn-primary float-right">Add New FDR plan</a>
                    </div>
                </div>
            </div>
            <?php if(Session::has('message')): ?>
              <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                     
                      <th><?php echo e(__('Title')); ?></th>
                      <th><?php echo e(__('Minimum Amount')); ?></th>
                      <th><?php echo e(__('Maximum Amount')); ?></th>
                      <th><?php echo e(__('Duration')); ?></th>
                      <th><?php echo e(__('Created At')); ?></th>
                      <th><?php echo e(__('Status')); ?></th>
                      <th><?php echo e(__('Action')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $fdr_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fdr_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                     
                      <td><?php echo e($fdr_plan->title); ?></td>
                      <td class="align-middle">
                        <?php echo e($fdr_plan->min_amount); ?>

                      </td>
                      <td class="align-middle">
                        <?php echo e($fdr_plan->max_amount); ?>

                      </td>
                      <td>
                        <?php echo e($fdr_plan->duration); ?>

                      </td>
                      <td>
                        <?php echo e($fdr_plan->created_at); ?>

                      </td>
                      <td>
                        <?php echo e($fdr_plan->status == 0 ? 'Inactive' : 'Active'); ?>

                      </td>
                      <td>
                        <div class="dropdown d-inline">
                          <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Action
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item has-icon" href="<?php echo e(route('admin.fixed-deposit.show', $fdr_plan->id)); ?>"><i class="fa fa-eye"></i><?php echo e(__('View')); ?></a>
                            <a class="dropdown-item has-icon" href="<?php echo e(route('admin.fixed-deposit.edit', $fdr_plan->id)); ?>"><i class="fa fa-edit"></i><?php echo e(__('Edit')); ?></a>

                            <a class="dropdown-item has-icon delete-confirm" href="javascript:void(0)" data-id=<?php echo e($fdr_plan->id); ?>><i class="fa fa-trash"></i><?php echo e(__('Delete')); ?></a>

                            <form class="d-none" id="delete_form_<?php echo e($fdr_plan->id); ?>" action="<?php echo e(route('admin.fixed-deposit.destroy', $fdr_plan->id)); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                            </form>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <?php echo e($fdr_plans->links('vendor.pagination.bootstrap-4')); ?>

               
              </div>
          </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/fixeddeposit/index.blade.php ENDPATH**/ ?>