

<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<section>
    <div class="breadcrump-area text-center">
        <div class="breadcrump-title">
            <h4><?php echo e(__('Contact Us')); ?></h4>
        </div>
        <div class="breadcrump-body">
            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a> <span class="dash">/</span> <span><?php echo e(__('Contact Us')); ?></span>
        </div>
    </div>
</section>
<!-- breadcrumb area end -->

<!-- breadcrumb area start -->
<section>
    <div class="contact-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="contact-title text-center">
                        <h3><?php echo e(__('Contact Us')); ?></h3>
                       
                    </div>
                    <div class="contact-form">
                        <form action="<?php echo e(route('contact.send')); ?>" method="POST" class="basicform">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label><?php echo e(__('Name')); ?></label>
                                        <input type="text" placeholder="<?php echo e(__('Enter Your Name')); ?>" class="form-control" name="name" id="name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label><?php echo e(__('Email')); ?></label>
                                        <input type="email" placeholder="<?php echo e(__('Enter Your Email')); ?>" class="form-control" name="email" id="email">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label><?php echo e(__('Subject')); ?></label>
                                        <input type="text" placeholder="<?php echo e(__('Enter Your Subject')); ?>" class="form-control" name="subject" id="subject">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label><?php echo e(__('Message')); ?></label>
                                        <textarea name="message" class="form-control" placeholder="<?php echo e(__('Message')); ?>" name="message" id="message"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-btn">
                                        <button type="submit" class="f-right basicbtn"><?php echo e(__('Send Message')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- breadcrumb area end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/admin/assets/js/form.js')); ?>"></script>
<script>
    "use strict";
    function success(res)
    {
        $('#name').val('');
        $('#email').val('');
        $('#subject').val('');
        $('#message').val('');
        console.log(res);
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/contact.blade.php ENDPATH**/ ?>