

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- hero area start -->
<section>
    <div class="hero-area"> 
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="slider-left-content">
                        <h2><?php echo e($titles->hero_title ?? ''); ?></h2>
                        <p><?php echo e($titles->hero_description ?? ''); ?></p>
                        <div class="slider-video-link">
                            <a href="<?php echo e($titles->hero_button_url ?? ''); ?>" class="popup">
                                <span class="iconify" data-icon="ant-design:play-circle-filled" data-inline="false"></span> <?php echo e($titles->hero_btn_title  ?? ''); ?>

                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-1"></div>
                <div class="col-lg-5">
                    <div class="payment-calculation">
                        <div id="input" class="input-section position-relative">
                            <div class="money-input-field">
                                <input type="number" placeholder="1,000" value="100" id="amount">
                                <span><?php echo e(__('You Send')); ?></span>
                            </div>
                            <div class="money-currency">
                                <a href="#"><span><img src="<?php echo e(asset('frontend/assets/img/flag/1.png')); ?>" alt=""> <span> <?php echo e(__('USD')); ?></span></span></a>
                            </div>
                        </div>
                        <div class="calculation-menu">
                            <nav>
                                <ul class="calc">
                                    <li>
                                        <span class="icon-area mct-1">
                                            <span class="iconify" data-icon="bx:bx-minus" data-inline="false"></span>
                                        </span>
                                        <span class="calculation-divison">
                                            <div class="charge" id="charge">
                                            </div>  
                                            <span class="calculation-payment-select">
                                                <select id="withdrawMethod">
                                                    <?php $__empty_1 = true; $__currentLoopData = $withdrawMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option 
                                                    data-charge-type ="<?php echo e($method->charge_type); ?>" 
                                                    data-min="<?php echo e($method->min_amount); ?>" data-max="<?php echo e($method->max_amount); ?>" 
                                                    data-fixed-charge="<?php echo e($method->fix_charge); ?>" 
                                                    data-percent-charge=<?php echo e($method->percent_charge); ?> 
                                                    value="<?php echo e($method->id); ?>"><?php echo e($method->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option 
                                                    data-charge-type ="0" 
                                                    data-min="0" data-max="0" 
                                                    data-fixed-charge="0" 
                                                    data-percent-charge=0 
                                                    value="0">--</option>
                                                    <?php endif; ?>
                                                  
                                                </select>
                                                <span class="free"><?php echo e(__('fee')); ?></span>
                                            </span>
                                        </span>
                                    </li>
                                     
                                    <li>
                                        <span class="icon-area">=</span>
                                        <span class="calculation-divison">
                                            <div class="charge" id="include_charge"></div>
                                            <span class="calculation-payment-select">
                                                <?php echo e(__("Amount We'll withdraw")); ?>

                                            </span>
                                        </span>
                                    </li>
                                    <li>
                                        <span class="icon-area"><span class="iconify" data-icon="eva:close-outline" data-inline="false"></span></span>
                                        <span class="calculation-divison">
                                            <div class="charge text-rate">
                                                <span id="rate"></span>
                                                <span class="iconify" data-icon="vaadin:trending-up" data-inline="false"></span></div>
                                            <span class="calculation-payment-select">
                                                <?php echo e(__('Guaranteed rate')); ?>

                                            </span>
                                        </span>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="input-section recepiet">
                            <div class="money-input-field">
                                <input type="number" id="final_amount" placeholder="83,876">
                                <span><?php echo e(__('Recipient Gets')); ?></span>
                            </div>
                            <div class="money-currency">
                                <a href="#" data-bs-toggle="dropdown" aria-expanded="false"><span><img id="country_flag" src="" alt=""> <span id="currency_name"> </span>&nbsp <span class="iconify" data-icon="dashicons:arrow-down-alt2" data-inline="false"></span></span></a>
                                <ul class="dropdown-menu dropdown-menu-end currency" id="currencyList">
                                </ul>
                                <input type="hidden" name="currency_name" id="currency_symbol">
                            </div>
                        </div>
                        <div class="calculation-checkout-btn">
                            <form action="<?php echo e(route('home.getstarted')); ?>" method="post" class="getStartedForm">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="" name="charge">
                                <input type="hidden" value="" name="currency">
                                <input type="hidden" value="" name="amount">
                                <input type="hidden" value="" name="withdrawmethod">
                                <button type="submit" id="getStarted"><?php echo e(__('Get Started')); ?></button>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- hero area end -->

<!-- how it works area start -->
<section>
    <div class="how-it-works-area pt-100 pb-100">
        <div class="container">
            
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-title text-center">
                        <h4><?php echo e($titles->hwt_title ?? ''); ?></h4>
                    </div>
                    <div class="section-des text-center">
                        <p><?php echo e($titles->hwt_description ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $howitworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $meta_data = json_decode($data->howitworksMeta->value);
                ?>
                <div class="col-lg-4">
                    <div class="single-how-it-works text-center">
                        <div class="img-section">
                            <img src="<?php echo e(asset($meta_data->image)); ?>" alt="">
                        </div>
                        <div class="title-section">
                            <h3><?php echo e($data->title); ?></h3>
                        </div>
                        <div class="content-section">
                            <p><?php echo e($meta_data->description); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- how it works area end -->

<!-- service area start -->
<section>
    <div class="service-area pt-100 pb-100">
        <div class="container">
            <div class="row">
               
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-title text-center">
                        <h4><?php echo e($titles->bst_title ?? ''); ?></h4>
                    </div>
                    <div class="section-des text-center">
                        <p><?php echo e($titles->bst_description ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="owl-carousel" id="service">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $meta_data = json_decode($data->serviceMeta->value);
                ?>
                <div class="col-lg-12">
                <div class="single-service">
                    <div class="service-icon">
                        <img src="<?php echo e(asset($meta_data->image)); ?>" alt="">
                    </div>
                    <div class="service-title">
                        <h3><?php echo e(Str::limit($data->title,12)); ?></h3>
                    </div>
                    <div class="service-des">
                        <p>
                            <?php echo e($meta_data->short_description); ?>

                        </p>
                    </div>
                    <div class="service-action">
                        <a href="<?php echo e(route('service.show',$data->slug)); ?>"><?php echo e(__('Learn More')); ?> <span class="iconify" data-icon="bi:arrow-right" data-inline="false"></span></a>
                    </div>
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- service area end -->

<!-- counter area start -->
<section>
    <?php
        $counter = json_decode($counter->value);
    ?>
    <div class="counter-area mb-100" style="background-image: url('<?php echo e(asset('frontend/assets/img/pattern.png')); ?>');">
        <div class="container">
            <div class="row counter-main-area">
                <div class="col-lg-3">
                    <div class="single-counter text-center">
                        <div class="counter-number">
                            <h2><?php echo e($counter->happy_customers_no); ?></h2>
                            <p><?php echo e($counter->happy_customers_title); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="single-counter text-center">
                        <div class="counter-number">
                            <h2><?php echo e($counter->year_banking_no); ?></h2>
                            <p><?php echo e($counter->year_banking_title); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="single-counter text-center">
                        <div class="counter-number">
                            <h2><?php echo e($counter->our_branches_no); ?></h2>
                            <p><?php echo e($counter->our_branches_title); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="single-counter text-center">
                        <div class="counter-number">
                            <h2><?php echo e($counter->successfully_work_no); ?></h2>
                            <p><?php echo e($counter->successfully_work_title); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- counter area end -->

<!-- sponser area start -->
<section>
    <div class="sponser-area pb-100">
        <div class="container">
            <div class="row">
               
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-title text-center">
                        <h4><?php echo e($titles->tit_title ?? ''); ?></h4>
                    </div>
                    <div class="section-des text-center">
                        <p><?php echo e($titles->tit_description ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $investors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $meta_data = json_decode($data->investor->value);
                ?>
                <div class="col-lg-3">
                    <div class="single-sponser text-center">
                        <div class="sponser-img">
                            <img class="img-fluid" src="<?php echo e(asset($meta_data->image)); ?>" alt="">
                        </div>
                        <div class="sponser-name">
                            <h3><?php echo e($data->title); ?></h3>
                        </div>
                        <div class="sponser-position">
                            <p><?php echo e($meta_data->position); ?></p>
                        </div>
                        <div class="sponser-social-links">
                            <nav>
                                <ul>
                                    <li><a href="<?php echo e($meta_data->facebook_link); ?>"><span class="iconify" data-icon="brandico:facebook" data-inline="false"></span></a></li>
                                    <li><a href="<?php echo e($meta_data->twitter_link); ?>"><span class="iconify" data-icon="ant-design:twitter-outlined" data-inline="false"></span></a></li>
                                    <li><a href="<?php echo e($meta_data->linkedin_link); ?>"><span class="iconify" data-icon="ant-design:linkedin-filled" data-inline="false"></span></a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- sponser area end -->

<!-- review area start -->
<section>
    <div class="review-area pb-100">
        <div class="container">
            <div class="row">
               
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-title text-center">
                        <h4><?php echo e($titles->client_title ?? ''); ?></h4>
                    </div>
                    <div class="section-des text-center">
                        <p><?php echo e($titles->client_description ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $meta_data = json_decode($data->feedback->value);
                ?>
                <div class="col-lg-6">
                    <div class="single-feedback text-center">
                        <div class="feedback-user-img">
                            <img src="<?php echo e(asset($meta_data->client_image)); ?>" alt="">
                        </div>
                        <div class="feedback-des">
                            <p><?php echo e($meta_data->client_review); ?></p>
                        </div>
                        <div class="feedback-user-name">
                            <h5><?php echo e($data->title); ?></h5>
                        </div>
                        <div class="feedback-user-position">
                            <p><?php echo e($meta_data->client_position); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- review area end -->

<!-- blog area start -->
<section>
    <div class="blog-area pb-100">
        <div class="container">
            <div class="row">
               
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-title text-center">
                        <h4><?php echo e($titles->lnt_title ?? ''); ?></h4>
                    </div>
                    <div class="section-des text-center">
                        <p><?php echo e($titles->lnt_description ?? ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="single-news">
                        <div class="news-img">
                            <a href="<?php echo e(route('blog.show',$data->slug)); ?>"><img class="img-fluid" src="<?php echo e(asset($data->thum_image->value)); ?>" alt=""></a>
                        </div>
                        <div class="news-content">
                            <div class="news-title">
                                <a href="<?php echo e(route('blog.show',$data->slug)); ?>"><h3><?php echo e($data->title); ?></h3></a>
                            </div>
                            <div class="news-des">
                                <p><?php echo e(Str::limit(strip_tags($data->description->value), 200)); ?></p>
                            </div>
                            <div class="news-action">
                                <a href="<?php echo e(route('blog.show',$data->slug)); ?>"><?php echo e(__('Learn More')); ?> <span class="iconify" data-icon="bi:arrow-right" data-inline="false"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- blog area end -->
<input type="hidden" id="get_currency_url" value="<?php echo e(route('home.getCurrencyList')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/assets/js/home.js?v=1.0.0')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/index.blade.php ENDPATH**/ ?>