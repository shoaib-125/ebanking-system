

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Automatic Gateway List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
            </div>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                     <th><?php echo e(__('Name')); ?></th>
                      <th><?php echo e(__('Logo')); ?></th>
                      <th><?php echo e(__('Maximum Limit')); ?></th>
                      <th><?php echo e(__('Created At')); ?></th>
                      <th><?php echo e(__('Action')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $automaticGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $automaticGateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                      <tr>
                      
                      <td><?php echo e($automaticGateway->name); ?></td>
                      <td class="align-middle"> 
                          <img width="80" src="<?php echo e(asset($automaticGateway->logo)); ?>" alt="<?php echo e($automaticGateway->logo); ?>">
                      </td>
                      <td><?php echo e($automaticGateway->deposit_max); ?></td>
                      <td><?php echo e(date('d-m-Y', strtotime($automaticGateway->created_at))); ?></td>
                      <td>
                        <?php if(Auth()->user()->can('deposit.automatic.gateway.edit')): ?> 
                        <div class="dropdown d-inline">
                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(__('Action')); ?>

                          </button>     
                          <div class="dropdown-menu">
                            <a class="dropdown-item has-icon" href="<?php echo e(route('admin.deposit.automatic.gateway.edit', $automaticGateway->id)); ?>"><i class="fa fa-edit"></i><?php echo e(__('Edit')); ?></a>
                          </div>
                        </div>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <div class="float-right">
                  <?php echo e($automaticGateways->links('vendor.pagination.bootstrap-4')); ?>

                </div>
            </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/admin/deposits/automatic_gateway.blade.php ENDPATH**/ ?>