

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Role Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-9">      
		<div class="card">
			<div class="card-body">
				<h4><?php echo e(__('Add Role')); ?></h4>
				<form method="post" action="<?php echo e(route('admin.role.store')); ?>" class="basicform_with_reset">
					<?php echo csrf_field(); ?>
					<div class="pt-20">
						<div class="form-group">
							<label for="name"><?php echo e(__('Role Name')); ?></label>
							<input type="text" required class="form-control" name="name" placeholder="Enter role name">
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="selectAll">
									<label class="custom-control-label checkAll" for="selectAll"><?php echo e(__('Permissions')); ?></label>
								</div>
								<hr>
								<?php $i = 1; ?>
								<?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row">
										<div class="col-3">
											<div class="form-check">
												<input type="checkbox" class="form-check-input" id="<?php echo e($i); ?>Management" value="<?php echo e($group->group_name); ?>" onclick="checkPermissionByGroup('role-<?php echo e($i); ?>-management-checkbox', this)">
												<label class="form-check-label" for="checkPermission"><?php echo e($group->group_name); ?></label>
											</div>
										</div>
										<div class="col-9 role-<?php echo e($i); ?>-management-checkbox">
											<?php
												$permissions = App\Models\User::getpermissionsByGroupName($group->group_name);
												$j = 1;
											?>
											<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="form-check">
									
													<input type="checkbox" class="form-check-input" name="permissions[]" id="checkPermission<?php echo e($permission->id); ?>" value="<?php echo e($permission->name); ?>">
													<label class="form-check-label" for="checkPermission<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label>
												</div>
												<?php  $j++; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<br>
										</div>
									</div>
									<?php  $i++; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>	
					</div>
				</div>
			</div>
		</div>
	<div class="col-lg-3">
		<div class="single-area">
			<div class="card">
				<div class="card-body">
					<div class="btn-publish">
						<button type="submit" class="btn btn-primary col-12 basicbtn"><i class="fa fa-save"></i> <?php echo e(__('Save')); ?></button>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('Backend/admin/assets/js/roles.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/admin/role/create.blade.php ENDPATH**/ ?>