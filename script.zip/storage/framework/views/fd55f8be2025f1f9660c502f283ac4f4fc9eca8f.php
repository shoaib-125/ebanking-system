

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'All Transaction List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row">
              <div class="col-6">
                <form action="<?php echo e(route('admin.all.transaction.search.report')); ?>">
                  <div class="form-row">
                      <div class="col-lg-5">
                          <div class="form-group">
                              <label><?php echo e(__('Start Date')); ?></label>
                              <input type="date" class="form-control" name="start_date" required>
                          </div>
                      </div>
                      <div class="col-lg-5">
                          <div class="form-group">
                              <label><?php echo e(__('End Date')); ?></label>
                              <input type="date" class="form-control" name="end_date" required>
                          </div>
                      </div>
                      <div class="col-lg-2 mt-2">
                          <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Search')); ?></button>
                      </div>                                    
                  </div>
                </form>
              </div>
              <div class="col-6 mt-2">
                 <form action="<?php echo e(route('admin.all.transaction.trx.report')); ?>">
                    <div class="input-group form-row mt-3">

                       <input type="text" class="form-control" placeholder="Search..." required="" name="value" autocomplete="off" value="">
                       <select class="form-control" name="type">
                    
                          <option value="trxid"><?php echo e(__('Transection No')); ?></option>
                       </select>
                       <div class="input-group-append">                                            
                          <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                       </div>
                    </div>
                  </form>
              </div>
            </div>
            <?php if(Session::has('message')): ?>
              <div class="alert alert-danger"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <?php if(isset($start_date)): ?>
            <strong><?php echo e(date('d-m-Y', strtotime($start_date))); ?> <?php echo e(__('Date To')); ?> <?php echo e(date('d-m-Y', strtotime($end_date))); ?> <?php echo e(__('Date Report')); ?></strong>
            <br>
            <?php endif; ?>
            <?php if(isset($trx_id)): ?>
            <strong><?php echo e(__('Search By')); ?> <?php echo e($trx_id); ?></strong>
            <br>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(__('User')); ?></th>
                        <th><?php echo e(__('Trx ID')); ?></th>
                        <th><?php echo e(__('Amount')); ?></th>
                        <th><?php echo e(__('Balance')); ?></th>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Status')); ?></th>
                        <th><?php echo e(__('Action')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($key+1); ?></td>
                      <td><a href="<?php echo e(route('admin.users.show', $row->user->id)); ?>"><?php echo e($row->user->name); ?></a></td>
                      <td>
                        <?php echo e($row->trxid); ?>

                      </td>
                      <td><?php echo e($row->amount); ?></td>
                      <td><?php echo e($row->balance); ?></td>
                      <td><?php echo e(date('d-m-Y', strtotime($row->created_at))); ?></td>
                      <td>
                          <?php if($row->status == 1): ?>
                          <span class="badge badge-success"><?php echo e(__('Success')); ?></span>
                          <?php else: ?>
                          <span class="badge badge-danger"><?php echo e(__('Faild')); ?></span>
                          <?php endif; ?>
                      </td>
                      <td>  
                        <a title="view" class="btn btn-info btn-sm" href="<?php echo e(route('admin.all.transaction.view', $row->id)); ?>">
                            <i class="fa fa-eye"></i>
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              <?php echo e($transactions->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/transaction/all_transaction.blade.php ENDPATH**/ ?>