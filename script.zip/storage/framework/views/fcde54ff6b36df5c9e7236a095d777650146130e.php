

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Account Statements List')); ?></h4>
                        </div>
                        <?php if(Session::has('message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(Session::get('message')); ?>

                        </p>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-header">
                                <h5><?php echo e(__('Statement')); ?></h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="btn-statement">
                                            <a class="btn btn-primary w-100" href="<?php echo e(route('user.own.bank.statement')); ?>"><?php echo e(__('Own Bank')); ?></a>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="btn-statement">
                                            <a class="btn btn-success w-100" href="<?php echo e(route('user.others.bank.statement')); ?>"><?php echo e(__('Others Bank')); ?></a>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="btn-statement">
                                            <a class="btn btn-warning w-100" href="<?php echo e(route('user.edeposit.statement')); ?>"><?php echo e(__('E-currency')); ?></a>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="btn-statement">
                                            <a class="btn btn-dark w-100" href="<?php echo e(route('user.bill.statement')); ?>"><?php echo e(__('Bill')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/user/statment/statment_index.blade.php ENDPATH**/ ?>