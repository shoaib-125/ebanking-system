

<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<section>
    <div class="breadcrump-area text-center">
        <div class="breadcrump-title">
            <h4><?php echo e($page->title); ?></h4>
        </div>
        <div class="breadcrump-body">
            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a> <span class="dash">/</span> <span><?php echo e($page->title); ?></span>
        </div>
    </div>
</section>
<!-- breadcrumb area end -->

<!-- page area start -->
<section>
    <div class="page-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-body">
                        <?php
                            $info = json_decode($page->page->value);
                        ?>
                        <p><?php echo e($info->page_excerpt); ?></p>
                        <p><?php echo e($info->page_content); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- page area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/page/show.blade.php ENDPATH**/ ?>