<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'User View'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-12">
      <!-- main Section -->
      <div class="row">
        <div class="col-md-5 col-lg-5 col-sm-12">
            <div class="card">
               <div class="card-body">
                  <div class="card profile-widget">
                     <div class="profile-widget-header d-flex ">
                        <img alt="image" src="<?php echo e(!empty($user_transactions->image) ? asset($user_transactions->image) : url('https://ui-avatars.com/api/?background=random&name='.$user_transactions->name)); ?>" class="rounded-circle profile-widget-picture mx-auto">
                     </div>
                  </div>
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th><?php echo e(__('Title')); ?></th>
                        <th><?php echo e(__('Description')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><?php echo e(__('First Name')); ?></td>
                        <td><?php echo e($user_transactions->first_name); ?></td>
                      </tr>
                      <tr>
                          <td><?php echo e(__('Last Name')); ?></td>
                          <td><?php echo e($user_transactions->last_name); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Account Number')); ?></td>
                        <td><?php echo e($user_transactions->account_number); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Email')); ?></td>
                        <td><?php echo e($user_transactions->email); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Phone')); ?></td>
                        <td><?php echo e($user_transactions->phone); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Balance')); ?></td>
                        <td><?php echo e($user_transactions->balance); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Status')); ?></td>
                        <td>
                          <?php if($user_transactions->status == 1): ?>
                            <span class='badge badge-success'><?php echo e(__('Active')); ?></span>
                          <?php else: ?>
                            <span class='badge badge-danger'><?php echo e(__('Deactive')); ?></span>
                          <?php endif; ?>
                         </td>
                      </tr>
                      <tr>
                        <td colspan=2>
                          <a href="<?php echo e(route('admin.users.edit', $user_transactions->id)); ?>" class="btn btn-primary btn-block"><?php echo e(__('Edit')); ?></a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
               </div>
            </div>
        </div>
         <!-- col 5 -->
         <div class="col-md-7 col-lg-7 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card card-statistic-1">
                          <div class="card-icon bg-primary">
                            <i class="far fa-user"></i>
                          </div>
                          <div class="card-wrap">
                            <div class="card-header">
                              <h4><?php echo e(__('TOTAL DEPOSITED')); ?></h4>
                            </div>
                            <div class="card-body">
                              <?php echo e($amount->deposit); ?>

                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card card-statistic-1">
                          <div class="card-icon bg-primary">
                            <i class="far fa-user"></i>
                          </div>
                          <div class="card-wrap">
                            <div class="card-header">
                              <h4><?php echo e(__('TOTAL WITHDRAWAL')); ?></h4>
                            </div>
                            <div class="card-body">
                              <?php echo e($amount->withdraw); ?>

                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="card card-statistic-1">
                          <div class="card-icon bg-primary">
                            <i class="far fa-user"></i>
                          </div>
                          <div class="card-wrap">
                            <div class="card-header">
                              <h4><?php echo e(__('TOTAL FEE')); ?></h4>
                            </div>
                            <div class="card-body">
                              <?php echo e($amount->fee); ?>

                            </div>
                          </div>
                        </div>
                      </div>
                    </div><!-- End card -->
                    <div class="row">
                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <a class="btn btn-primary" href="<?php echo e(route('admin.user.transaction.report', ['withdraw', $user_id])); ?>"> <?php echo e(__('Withdraw Report')); ?></a>
                        </div>
                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <a class="btn btn-info" href="<?php echo e(route('admin.user.transaction.report', ['all transaction', $user_id])); ?>"><?php echo e(__('Transaction Report')); ?></a>
                        </div>
                    </div><!-- End card -->
                    <br><br>
                    <div class="row">
                        <div class="col-12">
                            <h5><?php echo e(__('Add Debit / Credit Balance')); ?></h5>
                            <br>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal1" data-whatever="@mdo"><?php echo e(__('Balance Debit / Credit')); ?></button>
                        </div>
                        <!-- Model start -->
                    <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add Credits')); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <form method="POST" action="<?php echo e(route('admin.user.credits', $user_id)); ?>"  class="basicform_with_reset">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('PUT'); ?>
                              <div class="form-group">
                                <label><?php echo e(__('Select Balance Type')); ?></label>
                                <select class="form-control" name="bln_type" id="bln_type">

                                  <option value="debit"><?php echo e(__('Debit')); ?></option>
                                  <option value="credit"><?php echo e(__('Credit')); ?></option>
                                </select>
                              </div>
                              <div class="form-group">
                                <label><?php echo e(__('Amount')); ?></label>
                                <input type="number" class="form-control" name="amount" placeholder="Amount">
                              </div>
                              <div class="form-group">
                                <label><?php echo e(__('Description')); ?></label>
                                <textarea required class="form-control" name="description" cols="30" rows="10"></textarea>
                              </div>
                              <button type="submit" class="btn btn-primary basicbtn"><?php echo e(__('Add')); ?></button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  <!-- End Model -->
                    </div><!-- End card -->
                    <br>
                    <div class="row">
                        <div class="col-12">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo"><?php echo e(__('Email Send')); ?></button>
                        </div>
                    </div><!-- End card -->
                    <!-- Model start -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Send Email message')); ?></h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <form method="POST" action="<?php echo e(route('admin.user.transaction.mail', $user_id)); ?>" class="basicform">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="form-group">
                                  <label for="recipient-name" class="col-form-label"><?php echo e(__('Subject')); ?></label>
                                  <input type="text" class="form-control" id="recipient-name" name="subject">
                                </div>
                                <div class="form-group">
                                  <label for="message-text" class="col-form-label"><?php echo e(__('Message')); ?></label>
                                  <textarea name="msg" class="form-control" id="message-text"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary basicbtn"><?php echo e(__('Send message')); ?></button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    <!-- End Model -->
                </div>
            </div>
         </div>
         <!-- col 7 -->
      </div><!-- End Main Row -->

      <!-- Transection Section -->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <h5><?php echo e(__('Transactions list')); ?></h5>
                            <table class="table">
                               <tbody>
                                    <tr>
                                      <th><?php echo e(__('Trxid')); ?></th>
                                      <th><?php echo e(__('Amount')); ?></th>
                                      <th><?php echo e(__('Balance')); ?></th>
                                      <th><?php echo e(__('Fee')); ?></th>
                                      <th><?php echo e(__('Status')); ?></th>
                                      <th><?php echo e(__('Type')); ?></th>
                                    </tr>
                               </tbody>
                               <tbody>
                                 <?php $__currentLoopData = $user_transactions->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row->trxid); ?></td>
                                        <td><?php echo e($row->amount); ?></td>
                                        <td><?php echo e($row->balance); ?></td>
                                        <td><?php echo e($row->fee); ?></td>
                                        <?php if($row->status == 1): ?>
                                        <td class="text-success"><?php echo e(__('Active')); ?></td>
                                        <?php endif; ?>
                                        <?php if($row->status == 0): ?>
                                        <td class="text-danger"><?php echo e(__('Inactive')); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($row->type); ?></td>
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                            </table>
                        </div>
                    </div><!-- End card -->
                </div>
            </div>
   </div><!-- End col 12 -->
</div><!-- End row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/user/view.blade.php ENDPATH**/ ?>