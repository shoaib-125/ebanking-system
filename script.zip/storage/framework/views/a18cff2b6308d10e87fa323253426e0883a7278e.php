

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-lg-6">
                    <h4><?php echo e(__('All Deposits Lists - Complete')); ?></h4>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                     
                      <th><?php echo e(__('Trx')); ?></th>
                      <th><?php echo e(__('User')); ?></th>
                      <th><?php echo e(__('Payment Gateway')); ?></th>
                      <th><?php echo e(__('Amount')); ?></th>
                      <th><?php echo e(__('Charge')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                     
                      <td><?php echo e($deposit->trx); ?></td>
                      <td class="align-middle"> <?php echo e($deposit->user->name); ?></td>
                      <td><?php echo e($deposit->getway->name); ?></td>
                      <td><?php echo e($deposit->amount); ?></td>
                      <td><?php echo e($deposit->charge); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/deposits/complete.blade.php ENDPATH**/ ?>