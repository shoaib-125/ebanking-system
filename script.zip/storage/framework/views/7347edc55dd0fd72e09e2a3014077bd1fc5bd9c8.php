

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('Dashboard')); ?></h4>
                        </div>
                        <div class="section-body">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="single-card position-relative">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="count">
                                                    <h4 id="balance">
                                                        <span class="loader">
                                                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=100>
                                                        </span>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="icon">
                                                    <span class="iconify" data-icon="gridicons:money" data-inline="false"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="balence-label">
                                                    <p><?php echo e(__('Total Balence')); ?></p>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-card position-relative">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="count">
                                                    <h4 id="deposit">
                                                        <span class="loader">
                                                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=100>
                                                        </span>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="icon">
                                                    <span class="iconify" data-icon="bx:bxs-package" data-inline="false"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="balence-label">
                                                    <p><?php echo e(__('Total Deposit')); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-card position-relative">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="count">
                                                    <h4 id="withdraw">
                                                        <span class="loader">
                                                            <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=100>
                                                        </span>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="icon">
                                                    <span class="iconify" data-icon="uil:money-withdraw" data-inline="false"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="balence-label">
                                                    <p><?php echo e(__('Total Withdraw')); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Latest Transaction -->
                            <br>          
                            <div class="card">
                                <div class="card-header">
                                    <h5><?php echo e(__('Latest Transactions')); ?></h5>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table">
                                        <div class="table-loader text-center">
                                            <span class="loader">
                                                <img src="<?php echo e(asset('frontend/assets/img/loader.gif')); ?>" alt="" width=100>
                                            </span>
                                        </div>
                                        <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col"><?php echo e(__('Trx ID')); ?></th>
                                            <th scope="col"><?php echo e(__('Amount')); ?></th>
                                            <th scope="col"><?php echo e(__('Balance')); ?></th>
                                            <th scope="col"><?php echo e(__('Fee')); ?></th>
                                            <th scope="col"><?php echo e(__('Type')); ?></th>
                                            <th scope="col"><?php echo e(__('Status')); ?></th>
                                            <th scope="col"><?php echo e(__('Date / Time')); ?></th>
                                            <th scope="col"><?php echo e(__('Details')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody class="transactions">
                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<input type="hidden" id="user_info" value="<?php echo e(route("user.dashboard.user_info")); ?>">
<input type="hidden" id="transaction_url" value="<?php echo e(route("user.transaction.view", '' )); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('frontend/assets/js/dashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/user/dashboard.blade.php ENDPATH**/ ?>