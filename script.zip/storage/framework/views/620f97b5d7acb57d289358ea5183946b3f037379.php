

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<h4 class="mb-20"><?php echo e(__('Edit Menu')); ?></h4>
				<div class="row">
					<div class="col-lg-12">
						<form method="post"  class="basicform" action="<?php echo e(route('admin.menu.update',$info->id)); ?>">
							<?php echo csrf_field(); ?>
							<?php echo method_field('PUT'); ?>
							<div class="custom-form">
								<div class="form-group">
									<label for="name"><?php echo e(__('Menu Name')); ?></label>
									<input type="text" name="name" class="form-control" id="name" value="<?php echo e($info->name); ?>">
								</div>
								<div class="form-group">
									<label for="position"><?php echo e(__('Menu Position')); ?></label>
									<select class="custom-select mr-sm-2" id="position" name="position">
										<?php if(!empty($positions)): ?>
										<?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($row['position']); ?>" <?php if($info->position == $row['position']): ?> selected="" <?php endif; ?>><?php echo e($row['position']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
										<option value="header" <?php if($info->position=='header'): ?> selected="" <?php endif; ?>><?php echo e(__('Header')); ?></option>
										
										<option value="footer_left"  <?php if($info->position=='footer_left'): ?> selected="" <?php endif; ?>><?php echo e(__('Footer Left')); ?></option>
										<option value="footer_right"  <?php if($info->position=='footer_right'): ?> selected="" <?php endif; ?>><?php echo e(__('Footer Right')); ?></option>
										<?php endif; ?>
									</select>
									
								</div>
								<div class="form-group">
									<label for="lang"><?php echo e(__('Select Language')); ?></label>
									<select class="custom-select mr-sm-2" id="lang" name="lang">
										<?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($row->name); ?>" <?php if($info->lang== $row->name): ?> selected="" <?php endif; ?>><?php echo e($row->data); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="form-group">
									<label for="position"><?php echo e(__('Menu Status')); ?></label>
									<select class="custom-select mr-sm-2" id="status" name="status">
										<option value="1" <?php if($info->status==1): ?> selected="" <?php endif; ?>><?php echo e(__('Active')); ?></option>
										<option value="0"  <?php if($info->status==0): ?> selected="" <?php endif; ?>><?php echo e(__('Draft')); ?></option>
									</select>
								</div>
								<button class="btn basicbtn btn-primary col-12 mt-10"><?php echo e(__('Update')); ?></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/admin/menu/edit.blade.php ENDPATH**/ ?>