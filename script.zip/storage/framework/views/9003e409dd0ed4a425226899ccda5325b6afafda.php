

<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<section>
    <div class="breadcrump-area text-center">
        <div class="breadcrump-title">
            <h4><?php echo e($service->title); ?></h4>
        </div>
        <div class="breadcrump-body">
            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a> <span class="dash">/</span> <span><?php echo e($service->title); ?></span>
        </div>
    </div>
</section>
<!-- breadcrumb area end -->

<!-- service area start -->
<section>
    <div class="service-area pt-100 pb-100 text-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php
                        $info = json_decode($service->serviceMeta->value);
                    ?>
                    <div class="service-img">
                        <img src="<?php echo e(asset($info->image)); ?>" alt="">
                    </div>
                    <div class="service-title">
                        <h3><?php echo e($service->title); ?></h3>
                    </div>
                    <div class="service-body">
                        <p><?php echo e($info->short_description); ?></p>
                        <p><?php echo $info->description; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- service area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\resources\views/service/show.blade.php ENDPATH**/ ?>