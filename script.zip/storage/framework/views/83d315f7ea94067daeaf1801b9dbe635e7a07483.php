

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-12">
      <!-- main Section -->
      <div class="row">
        <div class="col-md-8 offset-2">
            <div class="card">
               <div class="card-body">
                  <div class="card profile-widget">
                     <div class="profile-widget-header d-flex ">
                        <img alt="image" src="<?php echo e(!empty($user_transactions->image) ? asset($user_transactions->image) : url('https://ui-avatars.com/api/?background=random&name='.$user_transactions->name)); ?>" class="rounded-circle profile-widget-picture mx-auto">
                     </div>
                  </div>
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th><?php echo e(__('Title')); ?></th>
                        <th><?php echo e(__('Description')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><?php echo e(__('Name')); ?></td>
                        <td><?php echo e($user_transactions->name); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Email')); ?></td>
                        <td><?php echo e($user_transactions->email); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Phone')); ?></td>
                        <td><?php echo e($user_transactions->phone); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo e(__('Status')); ?></td>
                        <td>
                          <?php if($user_transactions->status == 1): ?>
                            <span class='badge badge-success'><?php echo e(__('Active')); ?></span>
                          <?php else: ?> 
                            <span class='badge badge-danger'><?php echo e(__('Not Active')); ?></span>
                          <?php endif; ?>
                         </td>
                      </tr>
                      <tr>
                        <td colspan=2>
                          <a href="<?php echo e(route('admin.profile.edit', $user_transactions->id)); ?>" class="btn btn-primary btn-block"><?php echo e(__('Edit')); ?></a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
               </div>
            </div>
        </div>
      </div><!-- End Main Row -->
   </div><!-- End col 12 -->
</div><!-- End row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/user/profile.blade.php ENDPATH**/ ?>