

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Completed FDR'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-lg-6">
                    <h4><?php echo e(__('Fixed Deposit Completed Lists')); ?></h4>
                </div>
                <div class="col-lg-6">
                    
                </div>
            </div>
            <?php if(Session::has('success')): ?>
              <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
              <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped" id="table-2">
                  <thead>
                    <tr>
                      <th><?php echo e(__('User Name')); ?></th>
                      <th><?php echo e(__('Package Name')); ?></th>
                      <th><?php echo e(__('Total Amount')); ?></th>
                      <th><?php echo e(__('Total Return')); ?></th>
                      <th><?php echo e(__('Return Date')); ?></th>
                      <th><?php echo e(__('Status')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $deposit_complete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><a href="<?php echo e(url('/admin/users',$row->user->id)); ?>"><?php echo e($row->user->name); ?></a></td>
                      <td class="align-middle">
                        <?php echo e($row->fdrplan->title); ?>

                      </td>
                      <td>
                        <?php echo e($row->amount); ?>

                      </td>
                      <td><?php echo e($row->return_total); ?></td>
                      <td><?php echo e(date('d-m-Y', strtotime($row->return_date))); ?></td>
                      <td><span class="badge badge-success"><?php echo e(__('Complete')); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <?php echo e($deposit_complete->links('vendor.pagination.bootstrap-4')); ?>

              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ebank/script/resources/views/admin/fixeddeposit/complete.blade.php ENDPATH**/ ?>