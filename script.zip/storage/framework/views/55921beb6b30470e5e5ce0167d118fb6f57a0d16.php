

<?php $__env->startSection('content'); ?>
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('layouts.frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4><?php echo e(__('E-Deposit')); ?></h4>
                        </div>
                        <div class="section-body">
                           <div class="edeposit-area">
                               <div class="row">
                                   <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div class="col-lg-4">
                                       <div class="single-deposit text-center mb-4">
                                           <div class="deposit-img">
                                               <img class="img-fluid" src="<?php echo e(asset($gateway->logo)); ?>" alt="">
                                           </div>
                                           <div class="deposit-name">
                                               <h3><?php echo e(ucwords($gateway->name)); ?></h3>
                                           </div>
                                           <div class="requirments-menu">
                                                <nav>
                                                    <ul>
                                                        <li><?php echo e(__('Limit')); ?>: <?php echo e($gateway->deposit_min); ?>-<?php echo e($gateway->deposit_max); ?></li>
                                                        <li><?php echo e(__('Charge')); ?>: <?php echo e($gateway->charge_type); ?></li>
                                                    </ul>
                                                </nav>
                                           </div>
                                           <div class="desposit-action">
                                               <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($gateway->id); ?>"><?php echo e(__('Deposit Now')); ?></a>
                                           </div>
                                       </div>
                                   </div>
                                   <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo e($gateway->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(ucwords($gateway->name)); ?> </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="POST" action="<?php echo e(route('user.edeposit.check', $gateway->id)); ?>" class="basicform" novalidate="">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e(route('user.edeposit.payment')); ?>" class="redirectUrl">
                                                <?php if($gateway->type == 0): ?>
                                                    <label for="currency"><?php echo e(__('Currency')); ?></label>
                                                    <select name="currency" id="" class="form-control">
                                                        <?php $__currentLoopData = $gateway->term; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select> 
                                                <?php endif; ?>
                                                <div class="form-group">
                                                    <label for="email"><?php echo e(__('Enter Amount (USD)')); ?></label>
                                                    <input type="number" class="form-control" name="amount" tabindex="1" required autofocus placeholder="<?php echo e(__('Amount')); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <div class="button-btn">
                                                        <button type="submit" class="basicbtn w-100" tabindex="4">
                                                            <?php echo e(__('Submit')); ?>

                                                        </button>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('frontend/assets/js/transfer/redirect.js')); ?>"></script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/user/edeposit/index.blade.php ENDPATH**/ ?>