<!-- footer area start -->
<footer>
    <div class="footer-area footer-demo-1">
        <div class="container">
            <?php
                $theme_settings = App\Models\Option::where('key','theme_settings')->first();
                $info = json_decode($theme_settings->value);
            ?>
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer-left-area">
                        <div class="footer-logo">
                            <img src="<?php echo e(asset('uploads/logo.png')); ?>" alt="">
                            <div class="footer-content">
                                <p><?php echo e($info->footer_description); ?></p>
                            </div>
                            <div class="agent-social-links">
                                <nav>
                                    <ul>
                                        <?php $__currentLoopData = $info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($value->link); ?>"><span class="iconify" data-icon="<?php echo e($value->icon); ?>" data-inline="false"></span></a></li>  
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-menu">
                        <?php echo e(footer_menu('footer_left')); ?>

                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-menu">
                         <?php echo e(footer_menu('footer_right')); ?>

                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer-newsletter">
                        <div class="footer-menu-title">
                            <h4><?php echo e(__('Newsletter')); ?></h4>
                        </div>
                        <div class="footer-content">
                            <p><?php echo e($info->newsletter_address); ?></p>
                        </div>
                        <div class="footer-newsletter-input">
                            <form action="<?php echo e(route('newsletter')); ?>" id="newsletter" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="email" name="email" placeholder="Enter Your Email Address" id="subscribe_email">
                                <button type="submit" class="basicbtn"><?php echo e(__('Subscribe')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom-area footer-demo-1">
        <div class="footer-bottom-content text-center">
            <span><?php echo e(__('Copyright © Website')); ?> - <?php echo e(date('Y')); ?>. <?php echo e(__('Develop By')); ?> <a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></span>
        </div>
    </div>
</footer>
<!-- footer area end -->

   <?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/layouts/frontend/partials/footer.blade.php ENDPATH**/ ?>