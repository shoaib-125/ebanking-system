<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- css here -->
    <?php echo SEO::generate(true); ?>

     <link rel="icon" href="<?php echo e(asset('uploads/favicon.ico?v=1')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/font.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/hc-offcanvas-nav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/owl.carousel.min.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
    <!--- Header Section ---->
    <?php echo $__env->make('layouts.frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <?php echo $__env->yieldContent('content'); ?>

    <!--- footer Section ---->
    <?php echo $__env->make('layouts.frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- js here -->
    <script src="<?php echo e(asset('frontend/assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/iconify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/hc-offcanvas-nav.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/script.js')); ?>"></script>
    <?php if(Auth::check()): ?>
    <script src="<?php echo e(asset('backend/admin/assets/js/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/admin/assets/js/form.js')); ?>"></script>
    <?php endif; ?>
    <!-- Page Specific JS File -->
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\files\script\resources\views/layouts/frontend/app.blade.php ENDPATH**/ ?>