

<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('backend/admin/assets/css/summernote/summernote-bs4.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4><?php echo e(__('Add New Page')); ?></h4>
            </div>
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <strong><?php echo e(__('Whoops!')); ?></strong> <?php echo e(__('There were some problems with your input.')); ?><br><br>
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.pages.store')); ?>" enctype="multipart/form-data" class="basicform_with_reset">
              <?php echo csrf_field(); ?>
              <div class="card-body">
                <div class="form-group">
                  <label><?php echo e(__('Page Title')); ?></label>
                  <input type="text" class="form-control" placeholder="Page Title" required name="page_title">
                </div>

                <div class="form-group">
                    <label><?php echo e(__('Page excerpt')); ?></label>
                    <textarea name="page_excerpt" cols="30" rows="10" class="form-control"></textarea>
                </div>
          
                <div class="form-group">
                  <label><?php echo e(__('Page Content')); ?></label>
                  <textarea name="page_content" class="form-control"></textarea>
                </div>

              <div class="form-group">
                <div class="custom-file mb-3">
                  <label><?php echo e(__('Status')); ?></label>
                  <select name="status" class="form-control">
                  
                    <option value="1"><?php echo e(__('Active')); ?></option>
                    <option value="0"><?php echo e(__('Inactive')); ?></option>
                  </select>
                </div>
              </div>
              <div class="row">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn"><?php echo e(__('Submit')); ?></button>
                  </div>
                </div>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
  <script src="<?php echo e(asset('backend/admin/assets/js/summernote-bs4.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Bank\script\resources\views/admin/pages/create.blade.php ENDPATH**/ ?>