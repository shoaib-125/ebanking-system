

<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<section>
    <div class="breadcrump-area text-center">
        <div class="breadcrump-title">
            <h4><?php echo e(__('All Services')); ?></h4>
        </div>
        <div class="breadcrump-body">
            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a> <span class="dash">/</span> <span><?php echo e(__('All Services')); ?></span>
        </div>
    </div>
</section>
<!-- breadcrumb area end -->

<!-- services area start -->
<section>
    <div class="services-area pt-100 pb-100">
        <div class="container">
            <div class="owl-carousel" id="service">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $meta_data = json_decode($data->serviceMeta->value);
                ?>
                <div class="col-lg-12">
                <div class="single-service">
                    <div class="service-icon">
                        <img src="<?php echo e(asset($meta_data->image)); ?>" alt="">
                    </div>
                    <div class="service-title">
                        <h3><?php echo e(Str::limit($data->title,12)); ?></h3>
                    </div>
                    <div class="service-des">
                        <p>
                            <?php echo e($meta_data->short_description); ?>

                        </p>
                    </div>
                    <div class="service-action">
                        <a href="<?php echo e(route('service.show',$data->slug)); ?>"><?php echo e(__('Learn More')); ?> <span class="iconify" data-icon="bi:arrow-right" data-inline="false"></span></a>
                    </div>
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- services area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\resources\views/service/index.blade.php ENDPATH**/ ?>