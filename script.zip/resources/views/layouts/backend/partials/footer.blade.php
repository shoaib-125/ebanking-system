<footer class="main-footer">
    <div class="footer-left">
      Copyright &copy; {{ date('Y') }} <div class="bullet"></div> Develop By <a href="{{ url('/') }}/">{{ env('APP_NAME') }}</a>
    </div>
    <div class="footer-right">
      1.0
    </div>
  </footer>